import os
import shutil
import zipfile
import uuid
from fastapi import FastAPI, File, UploadFile, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import List, Dict, Any, Optional

from core.skills.manager import SkillManager
from core.ai.analyzer import AIAnalyzer
from core.storage.result_store import ResultStore
from core.storage.models import AuditResult, VulnerabilityRecord, VulnerabilitySeverity, VulnerabilityStatus

app = FastAPI(title="代码审计平台 API", version="1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

skill_manager = SkillManager()
result_store = ResultStore()

UPLOADS_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "uploads")
os.makedirs(UPLOADS_DIR, exist_ok=True)

CODE_EXTENSIONS = {".py", ".js", ".jsx", ".ts", ".tsx", ".php", ".java", ".go", ".cpp", ".c", ".rb", ".rs", ".swift", ".kt", ".html", ".htm", ".xml", ".json", ".yaml", ".yml", ".md", ".sql", ".sh", ".bat", ".ps1"}

class AuditRequest(BaseModel):
    project_name: str
    ai_analysis: bool = True
    static_analysis: bool = True
    enabled_skills: List[str] = []

class SkillInfo(BaseModel):
    skill_id: str
    name: str
    description: str
    category: str
    enabled: bool = True

class AuditResponse(BaseModel):
    task_id: str
    status: str
    message: str

class VulnerabilityInfo(BaseModel):
    vulnerability_id: str
    type: str
    severity: str
    file_path: str
    line: int
    description: str

class AuditResultInfo(BaseModel):
    task_id: str
    project_name: str
    status: str
    vulnerabilities: List[VulnerabilityInfo]
    summary: Dict[str, Any]

def is_code_file(filename: str) -> bool:
    """判断是否为代码文件"""
    _, ext = os.path.splitext(filename.lower())
    return ext in CODE_EXTENSIONS

def extract_zip(file_path: str, dest_dir: str) -> None:
    """解压 zip 文件"""
    with zipfile.ZipFile(file_path, 'r') as zip_ref:
        zip_ref.extractall(dest_dir)

def get_all_code_files(root_dir: str) -> List[str]:
    """获取所有代码文件路径"""
    code_files = []
    for dirpath, dirnames, filenames in os.walk(root_dir):
        for filename in filenames:
            if is_code_file(filename):
                code_files.append(os.path.join(dirpath, filename))
    return code_files

@app.post("/api/audit")
async def start_audit(
    project_name: str = Form(...),
    ai_analysis: bool = Form(True),
    static_analysis: bool = Form(True),
    enabled_skills: str = Form("[]"),
    files: List[UploadFile] = File(...)
):
    """开始审计任务 - 支持上传文件夹和 zip 文件"""
    import json
    enabled_skills_list = json.loads(enabled_skills)
    
    task_id = f"audit-{uuid.uuid4().hex[:8]}"
    
    project_upload_dir = os.path.join(UPLOADS_DIR, task_id)
    os.makedirs(project_upload_dir, exist_ok=True)
    
    uploaded_files = []
    
    for file in files:
        file_path = os.path.join(project_upload_dir, file.filename)
        
        with open(file_path, 'wb') as f:
            f.write(await file.read())
        
        if file.filename.lower().endswith('.zip'):
            extract_dir = os.path.join(project_upload_dir, os.path.splitext(file.filename)[0])
            os.makedirs(extract_dir, exist_ok=True)
            extract_zip(file_path, extract_dir)
            os.remove(file_path)
            extracted_files = get_all_code_files(extract_dir)
            uploaded_files.extend(extracted_files)
        else:
            uploaded_files.append(file_path)
    
    result = AuditResult(
        task_id=task_id,
        project_id=f"proj-{uuid.uuid4().hex[:8]}",
        project_name=project_name,
        source_path=project_upload_dir,
        status="running"
    )
    
    vulnerabilities = []
    
    if static_analysis:
        for file_path in uploaded_files:
            if os.path.exists(file_path) and is_code_file(file_path):
                filename = os.path.basename(file_path)
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                
                if "subprocess.run" in content and "shell=True" in content:
                    vulnerabilities.append(VulnerabilityRecord(
                        vulnerability_id=f"VULN-{uuid.uuid4().hex[:6]}",
                        type="命令注入",
                        cwe="CWE-78",
                        severity=VulnerabilitySeverity.CRITICAL,
                        status=VulnerabilityStatus.DETECTED,
                        file_path=filename,
                        line=content.count('\n', 0, content.find("subprocess.run")) + 1,
                        description="用户输入直接传递给shell命令",
                        attack_vector="HTTP请求参数",
                        impact="远程命令执行"
                    ))
                
                if "f\"SELECT" in content or 'f\'SELECT' in content:
                    idx = content.find('f"SELECT') if 'f"SELECT' in content else content.find("f'SELECT")
                    vulnerabilities.append(VulnerabilityRecord(
                        vulnerability_id=f"VULN-{uuid.uuid4().hex[:6]}",
                        type="SQL注入",
                        cwe="CWE-89",
                        severity=VulnerabilitySeverity.CRITICAL,
                        status=VulnerabilityStatus.DETECTED,
                        file_path=filename,
                        line=content.count('\n', 0, idx) + 1 if idx >= 0 else 0,
                        description="SQL查询直接拼接用户输入",
                        attack_vector="HTTP请求参数",
                        impact="数据库信息泄露"
                    ))
    
    if ai_analysis:
        analyzer = AIAnalyzer()
        ai_results = analyzer.analyze_project(project_upload_dir)
        for ai_result in ai_results:
            for vuln in ai_result.vulnerabilities:
                vulnerabilities.append(VulnerabilityRecord(
                    vulnerability_id=f"VULN-{uuid.uuid4().hex[:6]}",
                    type=vuln.get("type", "未知漏洞"),
                    cwe=vuln.get("cwe", ""),
                    severity=VulnerabilitySeverity(vuln.get("severity", "high").lower()),
                    status=VulnerabilityStatus.DETECTED,
                    file_path=os.path.basename(ai_result.file_path),
                    line=vuln.get("location", {}).get("line", 0),
                    description=vuln.get("description", ""),
                    attack_vector=vuln.get("attack_vector", ""),
                    impact=vuln.get("impact", "")
                ))
    
    for vuln in vulnerabilities:
        result.add_vulnerability(vuln)
    
    result.status = "completed"
    result_store.save_result(result)
    
    return AuditResponse(
        task_id=task_id,
        status="completed",
        message=f"审计完成，共分析 {len(uploaded_files)} 个文件"
    )

@app.get("/api/skills")
async def get_skills():
    """获取所有技能列表"""
    skills = skill_manager.list_skills()
    return [SkillInfo(
        skill_id=skill.manifest.skill_id,
        name=skill.manifest.name,
        description=skill.manifest.description,
        category=skill.manifest.category.value
    ) for skill in skills]

@app.post("/api/skills/upload")
async def upload_skill(file: UploadFile = File(...)):
    """上传技能"""
    with tempfile.NamedTemporaryFile(delete=False, suffix=".zip") as temp_file:
        temp_file.write(await file.read())
        temp_path = temp_file.name
    
    try:
        skill_id = skill_manager.upload_skill(temp_path)
        if skill_id:
            return {"status": "success", "skill_id": skill_id}
        return {"status": "failed", "message": "上传失败"}
    finally:
        os.unlink(temp_path)

@app.delete("/api/skills/{skill_id}")
async def delete_skill(skill_id: str):
    """删除技能"""
    success = skill_manager.remove_skill(skill_id)
    return {"status": "success" if success else "failed"}

@app.get("/api/audit/{task_id}")
async def get_audit_result(task_id: str):
    """获取审计结果"""
    result = result_store.load_result(task_id)
    if not result:
        raise HTTPException(status_code=404, detail="任务未找到")
    
    vulnerabilities = []
    for vuln in result.vulnerabilities:
        vulnerabilities.append(VulnerabilityInfo(
            vulnerability_id=vuln.vulnerability_id,
            type=vuln.type,
            severity=vuln.severity.value,
            file_path=vuln.file_path,
            line=vuln.line,
            description=vuln.description
        ))
    
    return AuditResultInfo(
        task_id=result.task_id,
        project_name=result.project_name,
        status=result.status,
        vulnerabilities=vulnerabilities,
        summary=result.get_summary()
    )

@app.get("/api/audit/list")
async def list_audit_results():
    """获取审计任务列表"""
    task_ids = result_store.list_results()
    results = []
    for task_id in task_ids:
        summary = result_store.get_result_summary(task_id)
        if summary:
            results.append({
                "task_id": task_id,
                **summary
            })
    return results

@app.post("/api/config/llm")
async def configure_llm(api_key: str = Form(...), provider: str = Form("deepseek")):
    """配置LLM API密钥"""
    os.environ["LLM_API_KEY"] = api_key
    os.environ["LLM_PROVIDER"] = provider
    return {"status": "success", "message": "LLM配置已更新"}

@app.get("/api/config/llm")
async def get_llm_config():
    """获取LLM配置"""
    return {
        "provider": os.environ.get("LLM_PROVIDER", "deepseek"),
        "api_key_set": bool(os.environ.get("LLM_API_KEY"))
    }

app.mount("/", StaticFiles(directory="web", html=True), name="web")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)