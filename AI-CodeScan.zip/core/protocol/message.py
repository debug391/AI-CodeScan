from datetime import datetime
from enum import Enum
from typing import Any, Dict, Optional, List
from pydantic import BaseModel, Field


class MessageType(str, Enum):
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    RESULT = "result"
    TASK = "task"
    HEARTBEAT = "heartbeat"
    LOG = "log"
    COMMAND = "command"


class MessageStatus(str, Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"


class AgentMessage(BaseModel):
    agent_id: str = Field(..., description="发送消息的Agent ID")
    agent_type: str = Field(..., description="Agent类型: orchestrator/recon/analysis/verification")
    message_type: MessageType = Field(..., description="消息类型")
    content: Any = Field(..., description="消息内容")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="消息时间戳")
    context: Dict[str, Any] = Field(default_factory=dict, description="上下文信息")
    message_id: str = Field(..., description="消息唯一标识")
    parent_message_id: Optional[str] = Field(None, description="父消息ID（用于消息链）")
    task_id: Optional[str] = Field(None, description="关联的任务ID")
    status: MessageStatus = Field(MessageStatus.PENDING, description="消息处理状态")
    priority: int = Field(0, description="消息优先级: 0-10")
    tags: List[str] = Field(default_factory=list, description="消息标签")

    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }

    def to_dict(self) -> Dict[str, Any]:
        return self.dict(by_alias=True)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AgentMessage":
        return cls(**data)

    def is_error(self) -> bool:
        return self.message_type == MessageType.ERROR

    def is_result(self) -> bool:
        return self.message_type == MessageType.RESULT

    def is_task(self) -> bool:
        return self.message_type == MessageType.TASK