import asyncio
import json
from typing import Dict, Any, List
from datetime import datetime

from .message import AgentMessage, MessageType, MessageStatus
from .task_handoff import TaskHandoff, TaskContext, AgentType, TaskPriority, AuditPhase
from .protocol import AgentProtocol, TaskProtocol, InMemoryChannel


class MockWebProject:
    """模拟一个Web项目结构和代码"""
    
    PROJECT_STRUCTURE = {
        "src": {
            "app.py": """from flask import Flask, request, jsonify
import pymysql

app = Flask(__name__)
db = pymysql.connect(host='localhost', user='root', password='password')

@app.route('/login', methods=['POST'])
def login():
    username = request.form.get('username')
    password = request.form.get('password')
    query = f"SELECT * FROM users WHERE username='{username}' AND password='{password}'"
    cursor = db.cursor()
    cursor.execute(query)
    result = cursor.fetchone()
    if result:
        return jsonify({"success": True, "user": result[1]})
    return jsonify({"success": False})

@app.route('/search', methods=['GET'])
def search():
    keyword = request.args.get('q')
    query = f"SELECT * FROM products WHERE name LIKE '%{keyword}%'"
    cursor = db.cursor()
    cursor.execute(query)
    return jsonify(cursor.fetchall())

@app.route('/api/users', methods=['GET'])
def get_users():
    role = request.headers.get('X-Role', 'user')
    if role == 'admin':
        query = "SELECT * FROM users"
    else:
        query = "SELECT id, username FROM users"
    cursor = db.cursor()
    cursor.execute(query)
    return jsonify(cursor.fetchall())

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
""",
            "config.py": """SECRET_KEY = 'supersecretkey123'
DATABASE_URL = 'mysql://root:password@localhost/db'
ALLOWED_HOSTS = ['*']
DEBUG = True
""",
            "utils.py": """import hashlib

def hash_password(password):
    return hashlib.md5(password.encode()).hexdigest()

def validate_email(email):
    if '@' in email:
        return True
    return False
""",
            "routes": {
                "api.py": """from flask import Blueprint, request
import subprocess

api = Blueprint('api', __name__)

@api.route('/execute', methods=['POST'])
def execute_command():
    cmd = request.json.get('command')
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return {'output': result.stdout, 'error': result.stderr}

@api.route('/upload', methods=['POST'])
def upload_file():
    file = request.files['file']
    filename = request.form.get('filename', file.filename)
    file.save(f'/uploads/{filename}')
    return {'status': 'success'}
"""
            }
        },
        "requirements.txt": "Flask==2.0.1\npymysql==1.0.2",
        "README.md": "# Web Application\nA simple web application"
    }

    @staticmethod
    def get_file_list() -> List[str]:
        """获取项目文件列表"""
        files = []
        
        def traverse(path, structure):
            for name, content in structure.items():
                full_path = f"{path}/{name}" if path else name
                if isinstance(content, dict):
                    traverse(full_path, content)
                else:
                    files.append(full_path)
        
        traverse("", MockWebProject.PROJECT_STRUCTURE)
        return files

    @staticmethod
    def get_file_content(file_path: str) -> str:
        """获取文件内容"""
        path_parts = file_path.split('/')
        current = MockWebProject.PROJECT_STRUCTURE
        
        for part in path_parts:
            if part in current:
                current = current[part]
            else:
                return ""
        
        return current if isinstance(current, str) else ""


class ReconAgentImpl:
    """侦察代理实现"""
    
    def __init__(self, protocol: AgentProtocol):
        self.protocol = protocol
        self.logger = protocol._logger
        
    async def handle_task(self, message: AgentMessage):
        """处理侦察任务"""
        task_id = message.task_id
        payload = message.content.get('payload', {})
        action = payload.get('action', '')
        
        self.logger.log_task_receive(task_id=task_id, payload=payload)
        self.logger.log_task_process(task_id=task_id, status="Starting reconnaissance")
        
        if action == 'scan_project':
            await self.scan_project(task_id, payload)
        else:
            await self.protocol.send_error(
                content=f"Unknown action: {action}",
                task_id=task_id
            )
    
    async def scan_project(self, task_id: str, payload: Dict[str, Any]):
        """扫描项目结构"""
        self.logger.log_task_process(task_id=task_id, status="Discovering project structure")
        await asyncio.sleep(1)
        
        files = MockWebProject.get_file_list()
        
        self.logger.log_task_process(task_id=task_id, status="Analyzing technology stack")
        await asyncio.sleep(0.5)
        
        framework_info = {
            "name": "Flask",
            "version": "2.0.1",
            "language": "Python",
            "database": "MySQL"
        }
        
        risk_files = [
            "src/app.py",
            "src/config.py", 
            "src/routes/api.py"
        ]
        
        dependencies = ["Flask", "pymysql", "subprocess"]
        
        result = {
            "status": "completed",
            "discovered_files": files,
            "risk_files": risk_files,
            "framework_info": framework_info,
            "dependencies": dependencies,
            "scan_time": datetime.utcnow().isoformat()
        }
        
        self.logger.log_task_process(task_id=task_id, status="Reconnaissance completed")
        
        await self.protocol.send_result(
            content=result,
            task_id=task_id,
            target_agent_type="orchestrator"
        )


class AnalysisAgentImpl:
    """分析代理实现"""
    
    def __init__(self, protocol: AgentProtocol):
        self.protocol = protocol
        self.logger = protocol._logger
        
    async def handle_task(self, message: AgentMessage):
        """处理分析任务"""
        task_id = message.task_id
        payload = message.content.get('payload', {})
        action = payload.get('action', '')
        
        self.logger.log_task_receive(task_id=task_id, payload=payload)
        self.logger.log_task_process(task_id=task_id, status="Starting analysis")
        
        if action == 'analyze_files':
            await self.analyze_files(task_id, payload)
        else:
            await self.protocol.send_error(
                content=f"Unknown action: {action}",
                task_id=task_id
            )
    
    async def analyze_files(self, task_id: str, payload: Dict[str, Any]):
        """分析指定文件"""
        files = payload.get('files', [])
        self.logger.log_task_process(task_id=task_id, status=f"Analyzing {len(files)} files")
        
        vulnerabilities = []
        
        for file_path in files:
            content = MockWebProject.get_file_content(file_path)
            vulns = self._detect_vulnerabilities(file_path, content)
            vulnerabilities.extend(vulns)
            await asyncio.sleep(0.3)
        
        result = {
            "status": "completed",
            "vulnerabilities": vulnerabilities,
            "analyzed_files": files,
            "analysis_time": datetime.utcnow().isoformat()
        }
        
        self.logger.log_task_process(task_id=task_id, status=f"Analysis completed, found {len(vulnerabilities)} vulnerabilities")
        
        await self.protocol.send_result(
            content=result,
            task_id=task_id,
            target_agent_type="orchestrator"
        )
    
    def _detect_vulnerabilities(self, file_path: str, content: str) -> List[Dict[str, Any]]:
        """检测文件中的漏洞"""
        vulns = []
        
        if file_path == "src/app.py":
            if "f\"SELECT * FROM users WHERE" in content:
                vulns.append({
                    "id": "VULN-001",
                    "type": "SQL Injection",
                    "cwe": "CWE-89",
                    "severity": "Critical",
                    "file": file_path,
                    "line": 12,
                    "description": "SQL查询直接拼接用户输入",
                    "code_snippet": 'query = f"SELECT * FROM users WHERE username=\'{username}\' AND password=\'{password}\'"',
                    "attack_vector": "POST /login",
                    "impact": "可能导致认证绕过和数据泄露"
                })
            
            if "f\"SELECT * FROM products WHERE" in content:
                vulns.append({
                    "id": "VULN-002",
                    "type": "SQL Injection",
                    "cwe": "CWE-89",
                    "severity": "High",
                    "file": file_path,
                    "line": 20,
                    "description": "搜索接口存在SQL注入",
                    "code_snippet": 'query = f"SELECT * FROM products WHERE name LIKE \'%{keyword}%\'"',
                    "attack_vector": "GET /search?q=",
                    "impact": "可能导致数据泄露"
                })
        
        elif file_path == "src/config.py":
            if "DEBUG = True" in content:
                vulns.append({
                    "id": "VULN-003",
                    "type": "Debug Mode Enabled",
                    "cwe": "CWE-200",
                    "severity": "Medium",
                    "file": file_path,
                    "line": 4,
                    "description": "生产环境启用了调试模式",
                    "code_snippet": "DEBUG = True",
                    "attack_vector": "直接访问",
                    "impact": "可能泄露敏感信息"
                })
            
            if "password='password'" in content:
                vulns.append({
                    "id": "VULN-004",
                    "type": "Hardcoded Credentials",
                    "cwe": "CWE-798",
                    "severity": "Critical",
                    "file": file_path,
                    "line": 2,
                    "description": "配置文件中硬编码数据库密码",
                    "code_snippet": "DATABASE_URL = 'mysql://root:password@localhost/db'",
                    "attack_vector": "代码泄露",
                    "impact": "数据库凭证泄露"
                })
        
        elif file_path == "src/routes/api.py":
            if "subprocess.run(cmd, shell=True" in content:
                vulns.append({
                    "id": "VULN-005",
                    "type": "Command Injection",
                    "cwe": "CWE-78",
                    "severity": "Critical",
                    "file": file_path,
                    "line": 11,
                    "description": "用户输入直接传递给shell命令",
                    "code_snippet": "result = subprocess.run(cmd, shell=True, capture_output=True, text=True)",
                    "attack_vector": "POST /api/execute",
                    "impact": "可能导致远程命令执行"
                })
            
            if "file.save(f'/uploads/{filename}'" in content:
                vulns.append({
                    "id": "VULN-006",
                    "type": "Path Traversal",
                    "cwe": "CWE-22",
                    "severity": "High",
                    "file": file_path,
                    "line": 18,
                    "description": "文件名直接用于路径拼接，存在路径遍历风险",
                    "code_snippet": "file.save(f'/uploads/{filename}')",
                    "attack_vector": "POST /api/upload",
                    "impact": "可能覆盖任意文件"
                })
        
        return vulns


class OrchestratorAgentImpl:
    """协调器代理实现"""
    
    def __init__(self, protocol: TaskProtocol):
        self.protocol = protocol
        self.logger = protocol._logger
        self.project_context = None
        self.audit_complete = False
    
    async def start_audit(self, project_id: str, project_name: str, source_path: str):
        """启动审计工作流"""
        self.logger.log_info(f"Starting audit workflow for project: {project_name}")
        
        self.project_context = TaskContext(
            project_id=project_id,
            project_name=project_name,
            source_path=source_path,
            source_type="file",
            platform="web",
            audit_phase=AuditPhase.INITIALIZED
        )
        
        await self.protocol.send_info(f"Initializing audit for project: {project_name}")
        
        await self.dispatch_recon_task()
    
    async def handle_result(self, message: AgentMessage):
        """处理子代理返回的结果"""
        task_id = message.task_id
        content = message.content
        source_agent = message.agent_type
        
        self.logger.log_message_receive(
            message_type="result",
            source_agent=source_agent,
            message_id=message.message_id
        )
        
        if source_agent == "recon" and content.get("status") == "completed":
            await self.handle_recon_result(task_id, content)
        elif source_agent == "analysis" and content.get("status") == "completed":
            await self.handle_analysis_result(task_id, content)
    
    async def handle_recon_result(self, task_id: str, result: Dict[str, Any]):
        """处理侦察结果"""
        self.logger.log_task_process(task_id=task_id, status="Processing recon result")
        
        self.project_context.discovered_files = result.get("discovered_files", [])
        self.project_context.risk_files = result.get("risk_files", [])
        self.project_context.framework_info = result.get("framework_info", {})
        self.project_context.dependencies = result.get("dependencies", [])
        self.project_context.audit_phase = AuditPhase.RECON_COMPLETED
        
        self.logger.log_info(f"Recon completed. Found {len(self.project_context.discovered_files)} files, {len(self.project_context.risk_files)} high-risk files")
        
        if self.project_context.risk_files:
            await self.dispatch_analysis_task()
        else:
            self.logger.log_info("No risk files found, audit completed")
            self.audit_complete = True
    
    async def handle_analysis_result(self, task_id: str, result: Dict[str, Any]):
        """处理分析结果"""
        self.logger.log_task_process(task_id=task_id, status="Processing analysis result")
        
        vulnerabilities = result.get("vulnerabilities", [])
        self.project_context.findings = vulnerabilities
        self.project_context.audit_phase = AuditPhase.ANALYSIS_COMPLETED
        
        self.logger.log_info(f"Analysis completed. Found {len(vulnerabilities)} vulnerabilities")
        
        self._print_vulnerability_summary(vulnerabilities)
        self.audit_complete = True
    
    def _print_vulnerability_summary(self, vulnerabilities: List[Dict[str, Any]]):
        """打印漏洞摘要"""
        print("\n" + "="*70)
        print("漏洞分析报告")
        print("="*70)
        
        severity_counts = {"Critical": 0, "High": 0, "Medium": 0, "Low": 0}
        for vuln in vulnerabilities:
            severity = vuln.get("severity", "Medium")
            severity_counts[severity] += 1
        
        print(f"\n漏洞统计:")
        print(f"  Critical: {severity_counts['Critical']}")
        print(f"  High: {severity_counts['High']}")
        print(f"  Medium: {severity_counts['Medium']}")
        print(f"  Low: {severity_counts['Low']}")
        
        print("\n漏洞详情:")
        for vuln in vulnerabilities:
            print(f"\n  [{vuln['id']}] {vuln['type']}")
            print(f"    严重程度: {vuln['severity']}")
            print(f"    位置: {vuln['file']}:{vuln['line']}")
            print(f"    描述: {vuln['description']}")
            print(f"    攻击向量: {vuln['attack_vector']}")
        
        print("\n" + "="*70)
    
    async def dispatch_recon_task(self):
        """分发侦察任务"""
        self.project_context.audit_phase = AuditPhase.RECON
        
        await self.protocol.dispatch_task(
            target_agent=AgentType.RECON,
            payload={
                "action": "scan_project",
                "path": self.project_context.source_path
            },
            context=self.project_context.model_dump(),
            priority=TaskPriority.HIGH,
            deadline_minutes=30
        )
    
    async def dispatch_analysis_task(self):
        """分发分析任务"""
        self.project_context.audit_phase = AuditPhase.ANALYSIS
        
        await self.protocol.dispatch_task(
            target_agent=AgentType.ANALYSIS,
            payload={
                "action": "analyze_files",
                "files": self.project_context.risk_files,
                "rules": ["sqli", "xss", "cmd_injection", "path_traversal", "hardcoded"]
            },
            context=self.project_context.model_dump(),
            priority=TaskPriority.HIGH,
            deadline_minutes=60
        )


async def run_full_workflow():
    """运行完整的审计工作流"""
    print("\n" + "="*70)
    print("启动代码审计平台 - 完整工作流演示")
    print("="*70)
    print("模拟场景: Flask Web应用安全审计")
    print("="*70 + "\n")
    
    channel = InMemoryChannel()
    
    orchestrator_protocol = TaskProtocol("orch-001", "orchestrator", channel)
    recon_protocol = AgentProtocol("recon-001", "recon", channel)
    analysis_protocol = AgentProtocol("analysis-001", "analysis", channel)
    
    orchestrator = OrchestratorAgentImpl(orchestrator_protocol)
    recon = ReconAgentImpl(recon_protocol)
    analysis = AnalysisAgentImpl(analysis_protocol)
    
    orchestrator_protocol.register_handler(MessageType.RESULT, orchestrator.handle_result)
    recon_protocol.register_handler(MessageType.TASK, recon.handle_task)
    analysis_protocol.register_handler(MessageType.TASK, analysis.handle_task)
    
    asyncio.create_task(recon_protocol.run())
    asyncio.create_task(analysis_protocol.run())
    asyncio.create_task(orchestrator_protocol.run())
    
    await orchestrator.start_audit(
        project_id="proj-flask-demo",
        project_name="Flask Demo Application",
        source_path="/tmp/flask-app"
    )
    
    while not orchestrator.audit_complete:
        await asyncio.sleep(0.5)
    
    print("\n" + "="*70)
    print("审计工作流完成")
    print("="*70)


if __name__ == "__main__":
    asyncio.run(run_full_workflow())