from datetime import datetime
from enum import Enum
from typing import Any, Dict, Optional, List
from pydantic import BaseModel, Field


class AgentType(str, Enum):
    ORCHESTRATOR = "orchestrator"
    RECON = "recon"
    ANALYSIS = "analysis"
    VERIFICATION = "verification"
    SKILL_EXECUTOR = "skill_executor"


class TaskPriority(int, Enum):
    LOW = 0
    MEDIUM = 1
    HIGH = 2
    CRITICAL = 3


class AuditPhase(str, Enum):
    INITIALIZED = "initialized"
    RECON = "recon"
    RECON_COMPLETED = "recon_completed"
    ANALYSIS = "analysis"
    ANALYSIS_COMPLETED = "analysis_completed"
    VERIFICATION = "verification"
    VERIFICATION_COMPLETED = "verification_completed"
    REPORTING = "reporting"
    COMPLETED = "completed"
    FAILED = "failed"


class TaskContext(BaseModel):
    project_id: str = Field(..., description="项目ID")
    project_name: str = Field(..., description="项目名称")
    source_path: str = Field(..., description="代码源路径")
    source_type: str = Field(..., description="源类型: file/git/url")
    platform: str = Field("web", description="目标平台: web/cs/client/app")
    audit_phase: AuditPhase = Field(AuditPhase.INITIALIZED, description="当前审计阶段")
    discovered_files: List[str] = Field(default_factory=list, description="已发现的文件列表")
    risk_files: List[str] = Field(default_factory=list, description="高风险文件列表")
    findings: List[Dict[str, Any]] = Field(default_factory=list, description="已发现的漏洞")
    framework_info: Dict[str, Any] = Field(default_factory=dict, description="框架信息")
    dependencies: List[str] = Field(default_factory=list, description="依赖列表")
    config: Dict[str, Any] = Field(default_factory=dict, description="配置参数")

    def add_finding(self, finding: Dict[str, Any]) -> None:
        self.findings.append(finding)

    def add_risk_file(self, file_path: str) -> None:
        if file_path not in self.risk_files:
            self.risk_files.append(file_path)


class TaskHandoff(BaseModel):
    task_id: str = Field(..., description="任务唯一标识")
    agent_type: AgentType = Field(..., description="目标Agent类型")
    payload: Dict[str, Any] = Field(default_factory=dict, description="任务负载")
    context: TaskContext = Field(..., description="任务上下文")
    priority: TaskPriority = Field(TaskPriority.MEDIUM, description="任务优先级")
    deadline: Optional[datetime] = Field(None, description="截止时间")
    max_retries: int = Field(3, description="最大重试次数")
    retry_count: int = Field(0, description="当前重试次数")
    created_at: datetime = Field(default_factory=datetime.utcnow, description="创建时间")
    expires_at: Optional[datetime] = Field(None, description="过期时间")
    correlation_id: Optional[str] = Field(None, description="关联ID")
    expected_output: Optional[str] = Field(None, description="期望输出类型")
    requires_confirmation: bool = Field(False, description="是否需要确认")

    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }

    def to_dict(self) -> Dict[str, Any]:
        return self.dict(by_alias=True)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TaskHandoff":
        return cls(**data)

    def is_expired(self) -> bool:
        if self.expires_at:
            return datetime.utcnow() > self.expires_at
        return False

    def increment_retry(self) -> bool:
        if self.retry_count < self.max_retries:
            self.retry_count += 1
            return True
        return False