import json
import uuid
import logging
from abc import ABC, abstractmethod
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Callable, AsyncIterator
from concurrent.futures import ThreadPoolExecutor
from collections import defaultdict

from .message import AgentMessage, MessageType, MessageStatus
from .task_handoff import TaskHandoff, AgentType, TaskPriority


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    handlers=[
        logging.StreamHandler()
    ]
)


class AuditLogger:
    def __init__(self, agent_id: str, agent_type: str):
        self.logger = logging.getLogger(f"Audit.{agent_type}.{agent_id}")
        self.agent_id = agent_id
        self.agent_type = agent_type

    def log_task_receive(self, task_id: str, payload: Dict[str, Any]) -> None:
        self.logger.info(f"[TASK_RECEIVE] task_id={task_id} payload_keys={list(payload.keys())}")

    def log_task_process(self, task_id: str, status: str) -> None:
        self.logger.info(f"[TASK_PROCESS] task_id={task_id} status={status}")

    def log_task_complete(self, task_id: str, result_summary: str) -> None:
        self.logger.info(f"[TASK_COMPLETE] task_id={task_id} result={result_summary}")

    def log_message_send(self, message_type: str, target_agent: Optional[str], message_id: str) -> None:
        self.logger.info(f"[MESSAGE_SEND] type={message_type} target={target_agent} msg_id={message_id}")

    def log_message_receive(self, message_type: str, source_agent: str, message_id: str) -> None:
        self.logger.info(f"[MESSAGE_RECEIVE] type={message_type} source={source_agent} msg_id={message_id}")

    def log_error(self, task_id: Optional[str], error: str) -> None:
        self.logger.error(f"[ERROR] task_id={task_id} error={error}")

    def log_warning(self, task_id: Optional[str], warning: str) -> None:
        self.logger.warning(f"[WARNING] task_id={task_id} warning={warning}")

    def log_info(self, message: str) -> None:
        self.logger.info(f"[INFO] {message}")


class MessageChannel(ABC):
    @abstractmethod
    async def send(self, message: AgentMessage) -> None:
        pass

    @abstractmethod
    async def receive(self, agent_id: str) -> AsyncIterator[AgentMessage]:
        pass

    @abstractmethod
    async def broadcast(self, message: AgentMessage, exclude_agent_ids: List[str] = None) -> None:
        pass


class InMemoryChannel(MessageChannel):
    def __init__(self):
        self._queues: Dict[str, List[AgentMessage]] = defaultdict(list)
        self._broadcast_queue: List[AgentMessage] = []
        self._executor = ThreadPoolExecutor(max_workers=4)
        self._logger = logging.getLogger("InMemoryChannel")

    async def send(self, message: AgentMessage) -> None:
        target_agent_type = message.context.get("target_agent_type")
        if target_agent_type:
            self._queues[target_agent_type].append(message)
            self._logger.debug(f"[CHANNEL] Sent message to queue '{target_agent_type}', queue_size={len(self._queues[target_agent_type])}")
        else:
            self._broadcast_queue.append(message)
            self._logger.debug(f"[CHANNEL] Broadcast message queued, broadcast_queue_size={len(self._broadcast_queue)}")

    async def receive(self, agent_id: str) -> AsyncIterator[AgentMessage]:
        agent_type = agent_id.split("-")[0] if "-" in agent_id else agent_id
        
        agent_type_mapping = {
            "orch": "orchestrator",
            "recon": "recon", 
            "analysis": "analysis",
            "verif": "verification",
            "skill": "skill_executor"
        }
        
        listening_type = agent_type_mapping.get(agent_type, agent_type)
        self._logger.debug(f"[CHANNEL] Receiver registered: agent_id={agent_id}, listening_on={listening_type}")
        
        while True:
            if self._queues.get(listening_type) and len(self._queues[listening_type]) > 0:
                message = self._queues[listening_type].pop(0)
                self._logger.debug(f"[CHANNEL] Delivered message to {agent_id}: msg_id={message.message_id}, type={message.message_type}")
                yield message
            elif self._broadcast_queue:
                message = self._broadcast_queue.pop(0)
                self._logger.debug(f"[CHANNEL] Delivered broadcast message to {agent_id}: msg_id={message.message_id}")
                yield message
            else:
                import asyncio
                await asyncio.sleep(0.1)

    async def broadcast(self, message: AgentMessage, exclude_agent_ids: List[str] = None) -> None:
        exclude_agent_ids = exclude_agent_ids or []
        for agent_type in self._queues.keys():
            if agent_type not in exclude_agent_ids:
                self._queues[agent_type].append(message)
                self._logger.debug(f"[CHANNEL] Broadcast to queue '{agent_type}'")


class AgentProtocol:
    def __init__(self, agent_id: str, agent_type: str, channel: MessageChannel):
        self.agent_id = agent_id
        self.agent_type = agent_type
        self.channel = channel
        self._message_handlers: Dict[MessageType, List[Callable]] = defaultdict(list)
        self._task_handlers: Dict[str, Callable] = {}
        self._logger = AuditLogger(agent_id, agent_type)
        self._logger.log_info(f"Agent initialized: {agent_type}-{agent_id}")

    def register_handler(self, message_type: MessageType, handler: Callable) -> None:
        self._message_handlers[message_type].append(handler)
        self._logger.log_info(f"Registered handler for message type: {message_type}")

    def register_task_handler(self, task_type: str, handler: Callable) -> None:
        self._task_handlers[task_type] = handler
        self._logger.log_info(f"Registered task handler for: {task_type}")

    def generate_message_id(self) -> str:
        return f"msg-{uuid.uuid4().hex[:8]}-{int(datetime.utcnow().timestamp())}"

    async def send_message(
        self,
        message_type: MessageType,
        content: Any,
        target_agent_type: Optional[str] = None,
        task_id: Optional[str] = None,
        parent_message_id: Optional[str] = None,
        priority: int = 0,
        tags: List[str] = None
    ) -> AgentMessage:
        message = AgentMessage(
            agent_id=self.agent_id,
            agent_type=self.agent_type,
            message_type=message_type,
            content=content,
            message_id=self.generate_message_id(),
            parent_message_id=parent_message_id,
            task_id=task_id,
            priority=priority,
            tags=tags or [],
            context={
                "target_agent_type": target_agent_type,
                "sender_agent_type": self.agent_type,
                "timestamp": datetime.utcnow().isoformat()
            }
        )
        
        self._logger.log_message_send(
            message_type=message_type.value,
            target_agent=target_agent_type,
            message_id=message.message_id
        )
        
        await self.channel.send(message)
        return message

    async def send_task(
        self,
        task_handoff: TaskHandoff
    ) -> AgentMessage:
        content = task_handoff.to_dict()
        message = await self.send_message(
            message_type=MessageType.TASK,
            content=content,
            target_agent_type=task_handoff.agent_type.value,
            task_id=task_handoff.task_id,
            priority=task_handoff.priority.value
        )
        self._logger.log_info(f"Task dispatched: {task_handoff.task_id} -> {task_handoff.agent_type.value}")
        return message

    async def send_info(self, content: str, **kwargs) -> AgentMessage:
        return await self.send_message(MessageType.INFO, content, **kwargs)

    async def send_warning(self, content: str, **kwargs) -> AgentMessage:
        return await self.send_message(MessageType.WARNING, content, **kwargs)

    async def send_error(self, content: str, **kwargs) -> AgentMessage:
        return await self.send_message(MessageType.ERROR, content, **kwargs)

    async def send_result(self, content: Any, task_id: str, **kwargs) -> AgentMessage:
        message = await self.send_message(MessageType.RESULT, content, task_id=task_id, **kwargs)
        result_summary = f"status={content.get('status', 'unknown')}" if isinstance(content, dict) else "result returned"
        self._logger.log_task_complete(task_id=task_id, result_summary=result_summary)
        return message

    async def send_heartbeat(self) -> AgentMessage:
        content = {
            "agent_id": self.agent_id,
            "agent_type": self.agent_type,
            "timestamp": datetime.utcnow().isoformat(),
            "status": "healthy"
        }
        return await self.send_message(MessageType.HEARTBEAT, content)

    async def broadcast_message(
        self,
        message_type: MessageType,
        content: Any,
        exclude_agent_ids: List[str] = None
    ) -> None:
        message = AgentMessage(
            agent_id=self.agent_id,
            agent_type=self.agent_type,
            message_type=message_type,
            content=content,
            message_id=self.generate_message_id(),
            context={"sender_agent_type": self.agent_type}
        )
        await self.channel.broadcast(message, exclude_agent_ids)

    async def handle_message(self, message: AgentMessage) -> None:
        self._logger.log_message_receive(
            message_type=message.message_type.value,
            source_agent=message.agent_type,
            message_id=message.message_id
        )
        
        handlers = self._message_handlers.get(message.message_type, [])
        
        if not handlers:
            self._logger.log_warning(task_id=message.task_id, warning=f"No handlers for message type: {message.message_type}")
            return
        
        for handler in handlers:
            try:
                await handler(message)
            except Exception as e:
                self._logger.log_error(task_id=message.task_id, error=str(e))
                await self.send_error(
                    content=f"Error handling message: {str(e)}",
                    parent_message_id=message.message_id
                )

    async def run(self) -> None:
        self._logger.log_info("Starting message listener...")
        async for message in self.channel.receive(self.agent_id):
            await self.handle_message(message)


class TaskProtocol(AgentProtocol):
    def create_task_handoff(
        self,
        target_agent: AgentType,
        payload: Dict[str, Any],
        context: Dict[str, Any],
        priority: TaskPriority = TaskPriority.MEDIUM,
        deadline_minutes: Optional[int] = None,
        max_retries: int = 3
    ) -> TaskHandoff:
        deadline = None
        if deadline_minutes:
            deadline = datetime.utcnow() + timedelta(minutes=deadline_minutes)
        
        task_id = f"task-{uuid.uuid4().hex[:8]}"
        self._logger.log_info(f"Created task handoff: {task_id} -> {target_agent.value}")
        
        return TaskHandoff(
            task_id=task_id,
            agent_type=target_agent,
            payload=payload,
            context=context,
            priority=priority,
            deadline=deadline,
            max_retries=max_retries
        )

    async def dispatch_task(
        self,
        target_agent: AgentType,
        payload: Dict[str, Any],
        context: Dict[str, Any],
        **kwargs
    ) -> AgentMessage:
        task_handoff = self.create_task_handoff(target_agent, payload, context, **kwargs)
        return await self.send_task(task_handoff)


class MessageSerializer:
    @staticmethod
    def serialize(message: AgentMessage) -> str:
        return json.dumps(message.to_dict())

    @staticmethod
    def deserialize(data: str) -> AgentMessage:
        data_dict = json.loads(data)
        return AgentMessage.from_dict(data_dict)

    @staticmethod
    def serialize_task(task: TaskHandoff) -> str:
        return json.dumps(task.to_dict())

    @staticmethod
    def deserialize_task(data: str) -> TaskHandoff:
        data_dict = json.loads(data)
        return TaskHandoff.from_dict(data_dict)