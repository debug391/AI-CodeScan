import asyncio
from typing import Dict, Any
from .message import AgentMessage, MessageType
from .task_handoff import TaskHandoff, TaskContext, AgentType, TaskPriority
from .protocol import AgentProtocol, TaskProtocol, InMemoryChannel


async def example_orchestrator_to_recon():
    channel = InMemoryChannel()
    
    orchestrator = TaskProtocol("orch-001", "orchestrator", channel)
    recon = AgentProtocol("recon-001", "recon", channel)

    async def handle_recon_result(message: AgentMessage):
        print(f"[Orchestrator] Received result: {message.content}")

    orchestrator.register_handler(MessageType.RESULT, handle_recon_result)

    async def handle_recon_task(message: AgentMessage):
        print(f"[Recon] Received task: {message.content}")
        
        result_content = {
            "status": "completed",
            "discovered_files": ["src/main.py", "src/auth/login.py"],
            "risk_files": ["src/auth/login.py"],
            "framework": "Flask",
            "dependencies": ["flask", "pymysql"]
        }
        
        await recon.send_result(
            content=result_content,
            task_id=message.task_id,
            target_agent_type="orchestrator"
        )

    recon.register_handler(MessageType.TASK, handle_recon_task)

    asyncio.create_task(recon.run())

    context = TaskContext(
        project_id="proj-001",
        project_name="Demo Project",
        source_path="/tmp/project",
        source_type="file",
        platform="web"
    )

    await orchestrator.dispatch_task(
        target_agent=AgentType.RECON,
        payload={"action": "scan_project", "path": "/tmp/project"},
        context=context,
        priority=TaskPriority.HIGH,
        deadline_minutes=30
    )

    await asyncio.sleep(1)


async def example_recon_to_analysis():
    channel = InMemoryChannel()
    
    recon = TaskProtocol("recon-001", "recon", channel)
    analysis = AgentProtocol("analysis-001", "analysis", channel)

    async def handle_analysis_result(message: AgentMessage):
        print(f"[Recon] Received analysis result: {message.content}")

    recon.register_handler(MessageType.RESULT, handle_analysis_result)

    async def handle_analysis_task(message: AgentMessage):
        print(f"[Analysis] Received task: {message.content}")
        
        result_content = {
            "status": "completed",
            "vulnerabilities": [
                {
                    "type": "SQL Injection",
                    "cwe": "CWE-89",
                    "severity": "Critical",
                    "location": {"file": "src/auth/login.py", "line": 42},
                    "description": "User input directly concatenated into SQL query"
                }
            ]
        }
        
        await analysis.send_result(
            content=result_content,
            task_id=message.task_id,
            target_agent_type="recon"
        )

    analysis.register_handler(MessageType.TASK, handle_analysis_task)

    asyncio.create_task(analysis.run())

    context = TaskContext(
        project_id="proj-001",
        project_name="Demo Project",
        source_path="/tmp/project",
        source_type="file",
        platform="web",
        discovered_files=["src/auth/login.py"],
        risk_files=["src/auth/login.py"]
    )

    await recon.dispatch_task(
        target_agent=AgentType.ANALYSIS,
        payload={
            "action": "analyze_files",
            "files": ["src/auth/login.py"],
            "rules": ["sqli", "xss"]
        },
        context=context,
        priority=TaskPriority.HIGH
    )

    await asyncio.sleep(1)


async def example_full_workflow():
    channel = InMemoryChannel()
    
    orchestrator = TaskProtocol("orch-001", "orchestrator", channel)
    recon = AgentProtocol("recon-001", "recon", channel)
    analysis = AgentProtocol("analysis-001", "analysis", channel)
    verification = AgentProtocol("verif-001", "verification", channel)

    async def orchestrator_handle_result(message: AgentMessage):
        print(f"[Orchestrator] Result from {message.agent_type}: {message.content}")
        
        if message.agent_type == "recon" and message.content.get("status") == "completed":
            context = TaskContext(
                project_id="proj-001",
                project_name="Demo Project",
                source_path="/tmp/project",
                source_type="file",
                platform="web",
                discovered_files=message.content.get("discovered_files", []),
                risk_files=message.content.get("risk_files", []),
                framework_info={"name": message.content.get("framework")},
                dependencies=message.content.get("dependencies", [])
            )
            
            await orchestrator.dispatch_task(
                target_agent=AgentType.ANALYSIS,
                payload={
                    "action": "analyze_files",
                    "files": message.content.get("risk_files", [])
                },
                context=context,
                priority=TaskPriority.HIGH
            )

        elif message.agent_type == "analysis" and message.content.get("status") == "completed":
            vulns = message.content.get("vulnerabilities", [])
            if vulns:
                context = TaskContext(
                    project_id="proj-001",
                    project_name="Demo Project",
                    source_path="/tmp/project",
                    platform="web",
                    findings=vulns
                )
                
                await orchestrator.dispatch_task(
                    target_agent=AgentType.VERIFICATION,
                    payload={
                        "action": "verify_vulnerabilities",
                        "vulnerabilities": vulns
                    },
                    context=context,
                    priority=TaskPriority.CRITICAL
                )

        elif message.agent_type == "verification" and message.content.get("status") == "completed":
            print(f"[Orchestrator] Audit completed! Verified {len(message.content.get('verified', []))} vulnerabilities")

    orchestrator.register_handler(MessageType.RESULT, orchestrator_handle_result)

    async def recon_handle_task(message: AgentMessage):
        print(f"[Recon] Scanning project...")
        await asyncio.sleep(0.5)
        
        result = {
            "status": "completed",
            "discovered_files": ["src/main.py", "src/auth/login.py", "src/config/db.py"],
            "risk_files": ["src/auth/login.py"],
            "framework": "Flask",
            "dependencies": ["flask", "pymysql", "werkzeug"]
        }
        
        await recon.send_result(
            content=result,
            task_id=message.task_id,
            target_agent_type="orchestrator"
        )

    recon.register_handler(MessageType.TASK, recon_handle_task)

    async def analysis_handle_task(message: AgentMessage):
        print(f"[Analysis] Analyzing files...")
        await asyncio.sleep(0.5)
        
        result = {
            "status": "completed",
            "vulnerabilities": [
                {
                    "type": "SQL Injection",
                    "cwe": "CWE-89",
                    "severity": "Critical",
                    "location": {"file": "src/auth/login.py", "line": 42},
                    "description": "User input directly concatenated into SQL query",
                    "code_snippet": "query = f\"SELECT * FROM users WHERE username='{username}'\""
                }
            ]
        }
        
        await analysis.send_result(
            content=result,
            task_id=message.task_id,
            target_agent_type="orchestrator"
        )

    analysis.register_handler(MessageType.TASK, analysis_handle_task)

    async def verification_handle_task(message: AgentMessage):
        print(f"[Verification] Verifying vulnerabilities...")
        await asyncio.sleep(0.5)
        
        vulns = message.content.get("vulnerabilities", [])
        verified = []
        
        for vuln in vulns:
            verified.append({
                **vuln,
                "verified": True,
                "poc_generated": True,
                "exploit_path": f"exploits/{vuln['cwe'].lower()}_exploit.py"
            })
        
        result = {
            "status": "completed",
            "verified": verified,
            "false_positives": []
        }
        
        await verification.send_result(
            content=result,
            task_id=message.task_id,
            target_agent_type="orchestrator"
        )

    verification.register_handler(MessageType.TASK, verification_handle_task)

    asyncio.create_task(recon.run())
    asyncio.create_task(analysis.run())
    asyncio.create_task(verification.run())

    await orchestrator.send_info("Starting audit workflow...")

    initial_context = TaskContext(
        project_id="proj-001",
        project_name="Demo Project",
        source_path="/tmp/project",
        source_type="file",
        platform="web"
    )

    await orchestrator.dispatch_task(
        target_agent=AgentType.RECON,
        payload={"action": "scan_project", "path": "/tmp/project"},
        context=initial_context,
        priority=TaskPriority.HIGH
    )

    await asyncio.sleep(3)


if __name__ == "__main__":
    print("=" * 60)
    print("Example 1: Orchestrator -> Recon")
    print("=" * 60)
    asyncio.run(example_orchestrator_to_recon())

    print("\n" + "=" * 60)
    print("Example 2: Recon -> Analysis")
    print("=" * 60)
    asyncio.run(example_recon_to_analysis())

    print("\n" + "=" * 60)
    print("Example 3: Full Workflow")
    print("=" * 60)
    asyncio.run(example_full_workflow())