from datetime import datetime
from enum import Enum
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field


class AnalysisMode(str, Enum):
    FAST = "fast"
    DEEP = "deep"
    FULL = "full"


class AIResult(BaseModel):
    analysis_id: str = Field(..., description="分析ID")
    file_path: str = Field(..., description="分析的文件路径")
    vulnerabilities: List[Dict[str, Any]] = Field(default_factory=list, description="发现的漏洞列表")
    code_understanding: str = Field("", description="代码理解")
    attack_surface: List[str] = Field(default_factory=list, description="攻击面")
    suggestions: List[str] = Field(default_factory=list, description="改进建议")
    confidence: float = Field(0.0, description="置信度")
    analysis_time: float = Field(0.0, description="分析时间")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="时间戳")


class AnalysisConfig(BaseModel):
    mode: AnalysisMode = Field(AnalysisMode.FAST, description="分析模式")
    max_tokens: int = Field(4096, description="最大Token数")
    temperature: float = Field(0.3, description="温度参数")
    top_p: float = Field(0.9, description="Top P参数")
    timeout: int = Field(300, description="超时时间")
    enable_code_understanding: bool = Field(True, description="启用代码理解")
    enable_vulnerability_detection: bool = Field(True, description="启用漏洞检测")
    enable_attack_surface_analysis: bool = Field(True, description="启用攻击面分析")
    severity_filter: List[str] = Field(default_factory=lambda: ["critical", "high", "medium"], description="严重程度过滤")