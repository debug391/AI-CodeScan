from typing import Dict, Any, List


class PromptManager:
    """提示词管理器 - 专注于攻防演练可利用漏洞"""

    # 高危漏洞类型列表
    HIGH_RISK_VULNERABILITIES = [
        "文件上传漏洞",
        "反序列化漏洞",
        "命令注入",
        "远程代码执行(RCE)",
        "SQL注入",
        "任意文件读取",
        "任意文件写入",
        "路径遍历",
        "服务器端请求伪造(SSRF)",
        "XXE注入",
        "模板注入(SSTI)",
        "XSS(存储型/反射型/DOM型)",
        "CSRF",
        "不安全的反序列化",
        "目录遍历",
        "代码注入",
        "表达式注入",
        "硬编码凭证",
        "敏感信息泄露"
    ]

    @staticmethod
    def get_vulnerability_detection_prompt(code: str, file_path: str, language: str = "Python") -> str:
        """获取漏洞检测提示词 - 专注于可利用的高危漏洞"""
        return f'''你是一名专业的渗透测试工程师，专注于攻防演练场景。

## 任务
分析以下代码，识别可被实际利用来获取目标系统权限的高危安全漏洞。

## 重点关注的漏洞类型
- 文件上传漏洞（可获取webshell）
- 反序列化漏洞（可执行任意代码）
- 命令注入（可执行系统命令）
- 远程代码执行(RCE)
- SQL注入（可获取数据库权限）
- 任意文件读取/写入
- 路径遍历
- SSRF（可访问内网服务）
- XXE注入
- 模板注入(SSTI)
- 其他可直接获取权限的高危漏洞

## 代码信息
文件名: {file_path}
语言: {language}

## 代码内容
```
{code}
```

## 分析要求
1. 只报告可被实际利用的高危漏洞
2. 评估漏洞是否可以获取网站/服务器/系统权限
3. 分析漏洞的攻击向量和利用条件
4. 提供详细的漏洞描述和利用思路

## 输出格式
请以JSON格式输出，只包含可利用的高危漏洞：
```json
{{
  "vulnerabilities": [
    {{
      "type": "漏洞类型",
      "cwe": "CWE编号",
      "severity": "Critical/High/Medium/Low",
      "location": {{
        "line": 行号,
        "column": 列号
      }},
      "description": "漏洞描述",
      "exploitability": "高/中/低",
      "can_get_shell": true/false,
      "attack_vector": "攻击向量",
      "impact": "影响范围（能否获取网站/服务器/系统权限）",
      "code_snippet": "问题代码片段",
      "exploit_method": "利用方法",
      "confidence": 置信度(0-1)
    }}
  ]
}}
```

## 注意事项
- 只报告实际可被利用的高危漏洞
- 对于无法获取权限的低危漏洞可以忽略
- 提供准确的位置信息和利用方法
'''

    @staticmethod
    def get_exploit_generation_prompt(vulnerability: Dict[str, Any], code_context: str) -> str:
        """获取利用脚本生成提示词"""
        return f'''你是一名专业的渗透测试工程师，请为以下高危漏洞生成完整的利用脚本。

## 漏洞信息
类型: {vulnerability.get("type", "")}
位置: {vulnerability.get("location", {})}
描述: {vulnerability.get("description", "")}
攻击向量: {vulnerability.get("attack_vector", "")}
能否获取Shell: {vulnerability.get("can_get_shell", False)}

## 代码上下文
```
{code_context}
```

## 输出要求
1. 如果漏洞可以获取shell，请生成完整可运行的exploit脚本
2. 脚本需要包含详细注释和使用说明
3. 提供多种利用方式（如果适用）
4. 包含验证漏洞存在的检测功能

## 输出格式
请以JSON格式输出：
```json
{{
  "scripts": [
    {{
      "name": "脚本名称",
      "language": "Python/Bash/JavaScript",
      "code": "完整脚本代码",
      "description": "脚本描述",
      "usage": "使用方法",
      "can_get_shell": true/false
    }}
  ]
}}
```
'''

    @staticmethod
    def get_webshell_detection_prompt(code: str, file_path: str) -> str:
        """获取WebShell检测提示词"""
        return f'''你是WebShell检测专家，请分析以下代码是否包含WebShell或后门。

## 代码信息
文件名: {file_path}

## 代码内容
```
{code}
```

## 分析要求
1. 识别是否存在WebShell特征
2. 分析代码是否包含恶意功能
3. 识别后门触发条件

## 输出格式
```json
{{
  "is_webshell": true/false,
  "risk_level": "High/Medium/Low",
  "signatures": ["特征1", "特征2"],
  "description": "分析描述",
  "malicious_functions": ["函数1", "函数2"],
  "trigger_condition": "触发条件"
}}
```
'''

    @staticmethod
    def get_payload_generation_prompt(vulnerability_type: str, target_info: str = "") -> str:
        """获取Payload生成提示词"""
        return f'''你是Payload生成专家，请为以下漏洞类型生成有效的攻击Payload。

## 漏洞类型
{ vulnerability_type }

## 目标信息（可选）
{ target_info }

## 输出要求
1. 生成多个不同类型的Payload
2. 包含绕过WAF的Payload
3. 提供Payload使用说明

## 输出格式
```json
{{
  "payloads": [
    {{
      "type": "Payload类型",
      "payload": "Payload内容",
      "description": "说明",
      "bypass_waf": true/false,
      "expected_result": "预期结果"
    }}
  ]
}}
```
'''

    @staticmethod
    def get_remediation_prompt(vulnerability: Dict[str, Any], code_context: str) -> str:
        """获取整改建议提示词"""
        return f'''你是安全修复专家，请为以下高危漏洞提供整改建议。

## 漏洞信息
类型: {vulnerability.get("type", "")}
位置: {vulnerability.get("location", {})}
描述: {vulnerability.get("description", "")}
严重程度: {vulnerability.get("severity", "High")}

## 问题代码
```
{code_context}
```

## 输出要求
1. 提供详细的修复方案
2. 给出修复后的代码示例
3. 解释修复原理
4. 提供参考链接

## 输出格式
```json
{{
  "title": "修复建议标题",
  "description": "详细描述",
  "fixed_code": "修复后的代码",
  "explanation": "修复原理",
  "references": ["参考链接1", "参考链接2"]
}}
```
'''