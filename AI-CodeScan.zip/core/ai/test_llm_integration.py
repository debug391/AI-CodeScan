import asyncio
import logging

logging.basicConfig(level=logging.INFO)

from core.ai.analyzer import AIAnalyzer


async def test_ai_analyzer():
    print("\n" + "="*70)
    print("LLM集成测试 - 高危漏洞检测")
    print("="*70)
    
    analyzer = AIAnalyzer()
    
    test_code = '''from flask import Flask, request
import subprocess

app = Flask(__name__)

@app.route('/execute', methods=['POST'])
def execute():
    cmd = request.json.get('command')
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return {"output": result.stdout}

@app.route('/upload', methods=['POST'])
def upload():
    file = request.files['file']
    filename = request.form.get('filename', file.filename)
    file.save(f'/uploads/{filename}')
    return {"status": "success"}

@app.route('/api/user', methods=['GET'])
def get_user():
    user_id = request.args.get('id')
    query = f"SELECT * FROM users WHERE id={user_id}"
    return query
'''
    
    print("\n1. 测试高危漏洞检测...")
    result = analyzer.analyze_code(test_code, "app.py")
    
    print(f"   分析完成，发现漏洞数: {len(result.vulnerabilities)}")
    
    for vuln in result.vulnerabilities:
        print(f"\n   [{vuln.get('cwe')}] {vuln.get('type')}")
        print(f"      严重程度: {vuln.get('severity')}")
        print(f"      可获取Shell: {vuln.get('can_get_shell')}")
        print(f"      描述: {vuln.get('description')}")
        print(f"      利用方法: {vuln.get('exploit_method')}")
    
    print("\n2. 测试Payload生成...")
    payloads = analyzer.generate_payloads("SQL注入")
    print(f"   生成Payload数量: {len(payloads.get('payloads', []))}")
    for p in payloads.get('payloads', [])[:3]:
        print(f"   - {p.get('type')}: {p.get('payload')}")
    
    print("\n3. 测试利用脚本生成...")
    vuln = {
        "type": "命令注入",
        "description": "用户输入直接传递给shell命令",
        "attack_vector": "POST请求参数",
        "can_get_shell": True
    }
    exploits = analyzer.generate_exploit(vuln, test_code)
    print(f"   生成脚本数量: {len(exploits.get('scripts', []))}")
    for script in exploits.get('scripts', []):
        print(f"   - {script.get('name')} ({script.get('language')})")
        print(f"     可获取Shell: {script.get('can_get_shell')}")
    
    print("\n" + "="*70)
    print("LLM集成测试完成")
    print("="*70)


if __name__ == "__main__":
    asyncio.run(test_ai_analyzer())