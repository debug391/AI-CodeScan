import os
import json
import logging
import requests
from typing import Dict, Any, Optional
from abc import ABC, abstractmethod

logger = logging.getLogger("LLMClient")


class LLMClient(ABC):
    """LLM客户端基类"""

    def __init__(self, api_key: str, base_url: str):
        self.api_key = api_key
        self.base_url = base_url

    @abstractmethod
    def generate(self, prompt: str, **kwargs) -> str:
        """生成响应"""
        pass


class DeepSeekClient(LLMClient):
    """DeepSeek LLM客户端"""

    def __init__(self, api_key: str):
        super().__init__(api_key, "https://api.deepseek.com")
        self.model = "deepseek-chat"

    def generate(self, prompt: str, **kwargs) -> str:
        """调用DeepSeek API生成响应"""
        url = f"{self.base_url}/chat/completions"
        
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }

        messages = [
            {"role": "system", "content": "You are a professional penetration tester and code security expert."},
            {"role": "user", "content": prompt}
        ]

        data = {
            "model": self.model,
            "messages": messages,
            "max_tokens": kwargs.get("max_tokens", 4096),
            "temperature": kwargs.get("temperature", 0.3),
            "top_p": kwargs.get("top_p", 0.9)
        }

        try:
            response = requests.post(url, headers=headers, json=data, timeout=60)
            response.raise_for_status()
            
            result = response.json()
            return result["choices"][0]["message"]["content"]
        
        except requests.exceptions.RequestException as e:
            logger.error(f"DeepSeek API error: {e}")
            return json.dumps({"error": str(e)})


class OpenAIClient(LLMClient):
    """OpenAI兼容客户端（支持OpenAI、Azure OpenAI等）"""

    def __init__(self, api_key: str, base_url: str = "https://api.openai.com"):
        super().__init__(api_key, base_url)
        self.model = "gpt-4o-mini"

    def generate(self, prompt: str, **kwargs) -> str:
        """调用OpenAI API生成响应"""
        url = f"{self.base_url}/v1/chat/completions"
        
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }

        messages = [
            {"role": "system", "content": "You are a professional penetration tester and code security expert."},
            {"role": "user", "content": prompt}
        ]

        data = {
            "model": self.model,
            "messages": messages,
            "max_tokens": kwargs.get("max_tokens", 4096),
            "temperature": kwargs.get("temperature", 0.3),
            "top_p": kwargs.get("top_p", 0.9)
        }

        try:
            response = requests.post(url, headers=headers, json=data, timeout=60)
            response.raise_for_status()
            
            result = response.json()
            return result["choices"][0]["message"]["content"]
        
        except requests.exceptions.RequestException as e:
            logger.error(f"OpenAI API error: {e}")
            return json.dumps({"error": str(e)})


class LLMFactory:
    """LLM客户端工厂"""

    @staticmethod
    def create_client(provider: str, api_key: str, base_url: str = None) -> LLMClient:
        """创建LLM客户端"""
        provider = provider.lower()
        
        if provider == "deepseek":
            return DeepSeekClient(api_key)
        elif provider == "openai":
            return OpenAIClient(api_key, base_url or "https://api.openai.com")
        elif provider == "azure":
            return OpenAIClient(api_key, base_url)
        else:
            raise ValueError(f"Unsupported LLM provider: {provider}")


def get_llm_client(provider: str = None, api_key: str = None) -> LLMClient:
    """获取LLM客户端（从环境变量读取配置）"""
    if not provider:
        provider = os.environ.get("LLM_PROVIDER", "deepseek")
    
    if not api_key:
        api_key = os.environ.get("LLM_API_KEY", "")
    
    if not api_key:
        logger.warning("LLM_API_KEY not set, using mock LLM")
        from .analyzer import MockLLM
        return MockLLM()
    
    base_url = os.environ.get("LLM_BASE_URL")
    
    return LLMFactory.create_client(provider, api_key, base_url)