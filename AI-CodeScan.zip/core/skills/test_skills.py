import os
import tempfile
import shutil
import logging

logging.basicConfig(level=logging.INFO)

from core.skills.manager import SkillManager
from core.skills.models import DetectionResult, SeverityLevel


def test_skill_manager():
    print("\n" + "="*70)
    print("技能系统测试")
    print("="*70)
    
    with tempfile.TemporaryDirectory() as temp_dir:
        skills_dir = os.path.join(temp_dir, "skills")
        
        manager = SkillManager(skills_dir)
        
        print("\n1. 初始化技能管理器...")
        result = manager.initialize()
        print(f"   初始化结果: {result}")
        
        print("\n2. 创建技能模板...")
        template_result = manager.create_skill_template(
            skill_id="sqli-detector",
            name="SQL注入检测器"
        )
        print(f"   创建模板结果: {template_result}")
        
        print("\n3. 重新加载技能...")
        manager.initialize(force_reload=True)
        
        print("\n4. 列出所有技能...")
        skills = manager.list_skills()
        print(f"   技能数量: {len(skills)}")
        for skill in skills:
            print(f"   - {skill.manifest.skill_id}: {skill.manifest.name}")
        
        print("\n5. 获取技能元数据...")
        metadata = manager.get_skill_metadata()
        print(f"   元数据: {metadata}")
        
        print("\n6. 创建测试项目目录...")
        test_project = os.path.join(temp_dir, "test_project")
        os.makedirs(test_project, exist_ok=True)
        
        vulnerable_code = '''
def login(username, password):
    query = f"SELECT * FROM users WHERE username='{username}' AND password='{password}'"
    execute_query(query)
'''
        with open(os.path.join(test_project, "auth.py"), 'w') as f:
            f.write(vulnerable_code)
        
        print("\n7. 执行检测...")
        results = manager.run_detection("sqli-detector", test_project)
        print(f"   检测结果数量: {len(results)}")
        
        print("\n8. 测试导出技能...")
        export_path = os.path.join(temp_dir, "sqli-detector.zip")
        export_result = manager.export_skill("sqli-detector", export_path)
        print(f"   导出结果: {export_result}")
        print(f"   文件大小: {os.path.getsize(export_path)} bytes")
        
        print("\n9. 测试上传技能...")
        new_skills_dir = os.path.join(temp_dir, "new_skills")
        new_manager = SkillManager(new_skills_dir)
        upload_result = new_manager.upload_skill(export_path)
        print(f"   上传结果: {upload_result}")
        
        print("\n10. 测试移除技能...")
        remove_result = manager.remove_skill("sqli-detector")
        print(f"   移除结果: {remove_result}")
        
        print("\n" + "="*70)
        print("技能系统测试完成")
        print("="*70)


if __name__ == "__main__":
    test_skill_manager()