import os
import zipfile
import tempfile
import shutil
import logging
from typing import Optional
from datetime import datetime

from .models import SkillManifest


logger = logging.getLogger("SkillUploader")


class SkillUploader:
    """技能上传器"""

    def __init__(self, skills_dir: str = "data/skills"):
        self.skills_dir = skills_dir
        os.makedirs(skills_dir, exist_ok=True)

    def upload_skill(self, zip_path: str) -> Optional[str]:
        """
        上传并安装技能
        
        Args:
            zip_path: 技能压缩包路径
            
        Returns:
            安装的技能ID，如果失败返回None
        """
        logger.info(f"Uploading skill from: {zip_path}")
        
        if not os.path.exists(zip_path):
            logger.error(f"File not found: {zip_path}")
            return None
        
        with tempfile.TemporaryDirectory() as temp_dir:
            try:
                with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                    zip_ref.extractall(temp_dir)
                
                skill_dirs = [d for d in os.listdir(temp_dir) if os.path.isdir(os.path.join(temp_dir, d))]
                
                if not skill_dirs:
                    logger.error("No skill directory found in zip")
                    return None
                
                skill_name = skill_dirs[0]
                extracted_path = os.path.join(temp_dir, skill_name)
                
                manifest_path = os.path.join(extracted_path, "skill.yaml")
                if not os.path.exists(manifest_path):
                    logger.error(f"skill.yaml not found in {extracted_path}")
                    return None
                
                manifest = SkillManifest.from_yaml(manifest_path)
                destination_path = os.path.join(self.skills_dir, manifest.skill_id)
                
                if os.path.exists(destination_path):
                    shutil.rmtree(destination_path)
                
                shutil.move(extracted_path, destination_path)
                
                requirements_path = os.path.join(destination_path, "requirements.txt")
                if os.path.exists(requirements_path):
                    self._install_dependencies(requirements_path)
                
                logger.info(f"Skill installed successfully: {manifest.skill_id}")
                return manifest.skill_id
                
            except Exception as e:
                logger.error(f"Failed to upload skill: {e}")
                return None

    def _install_dependencies(self, requirements_path: str) -> bool:
        """安装技能依赖"""
        try:
            import subprocess
            subprocess.run(
                ["pip", "install", "-r", requirements_path],
                check=True,
                capture_output=True
            )
            logger.info(f"Installed dependencies from {requirements_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to install dependencies: {e}")
            return False

    def validate_skill_structure(self, skill_path: str) -> bool:
        """验证技能结构"""
        required_files = ["skill.yaml", "detector.py", "exploit.py"]
        
        for file in required_files:
            if not os.path.exists(os.path.join(skill_path, file)):
                logger.error(f"Missing required file: {file}")
                return False
        
        manifest_path = os.path.join(skill_path, "skill.yaml")
        try:
            manifest = SkillManifest.from_yaml(manifest_path)
            
            if not manifest.skill_id:
                logger.error("skill_id is required")
                return False
            
            if not manifest.name:
                logger.error("name is required")
                return False
                
            return True
            
        except Exception as e:
            logger.error(f"Invalid skill.yaml: {e}")
            return False

    def create_skill_template(self, skill_id: str, name: str, output_path: str) -> bool:
        """创建技能模板"""
        template_dir = os.path.join(output_path, skill_id)
        os.makedirs(template_dir, exist_ok=True)
        
        manifest_content = f'''skill_id: {skill_id}
name: {name}
version: "1.0.0"
author: "Anonymous"
description: "A new skill"
category: web-security
platforms:
  - web
supported_languages:
  - Python
vulnerability:
  cwe: "CWE-000"
  severity: medium
execution:
  timeout: 300
  requires_env: false
dependencies: []
created_at: {datetime.utcnow().isoformat()}
updated_at: {datetime.utcnow().isoformat()}
'''
        with open(os.path.join(template_dir, "skill.yaml"), 'w') as f:
            f.write(manifest_content)
        
        detector_content = '''from core.skills.detector import FileDetector
from core.skills.models import DetectionResult, SeverityLevel


class Detector(FileDetector):
    """自定义漏洞检测器"""
    
    def __init__(self):
        super().__init__()
        self.supported_extensions = [".py", ".java", ".js"]
    
    def scan_file(self, file_path: str, content: str) -> list:
        results = []
        
        # 实现检测逻辑
        if "vulnerable_pattern" in content:
            results.append(DetectionResult(
                found=True,
                file_path=file_path,
                line=1,
                column=1,
                code_snippet="",
                vulnerability_type="Custom Vulnerability",
                severity=SeverityLevel.MEDIUM,
                confidence=0.85,
                metadata={}
            ))
        
        return results
'''
        with open(os.path.join(template_dir, "detector.py"), 'w') as f:
            f.write(detector_content)
        
        exploit_content = '''from core.skills.exploit_generator import BaseExploitGenerator
from core.skills.models import ExploitScript


class ExploitGenerator(BaseExploitGenerator):
    """自定义利用生成器"""
    
    def generate(self):
        scripts = []
        
        python_script = ExploitScript(
            name="exploit_python",
            language="python",
            code="# Exploit script here",
            description="Exploit script",
            requirements=[],
            parameters={},
            success_indicators=[]
        )
        scripts.append(python_script)
        
        return scripts
'''
        with open(os.path.join(template_dir, "exploit.py"), 'w') as f:
            f.write(exploit_content)
        
        with open(os.path.join(template_dir, "requirements.txt"), 'w') as f:
            f.write("")
        
        logger.info(f"Skill template created at: {template_dir}")
        return True