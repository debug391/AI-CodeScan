from abc import ABC, abstractmethod
from typing import List, Dict, Any
from .models import DetectionResult


class BaseDetector(ABC):
    """漏洞检测器基类"""

    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or {}

    @abstractmethod
    def detect(self, source_path: str) -> List[DetectionResult]:
        """
        执行漏洞检测
        
        Args:
            source_path: 源代码目录路径
            
        Returns:
            检测结果列表
        """
        raise NotImplementedError

    def get_audit_thoughts(self) -> List[str]:
        """
        获取审计思路
        
        Returns:
            审计思路列表
        """
        return []


class FileDetector(BaseDetector):
    """文件级检测器基类"""

    def __init__(self, config: Dict[str, Any] = None):
        super().__init__(config)
        self.supported_extensions = []

    def supports_file(self, file_path: str) -> bool:
        """检查是否支持该文件类型"""
        if not self.supported_extensions:
            return True
        return any(file_path.endswith(ext) for ext in self.supported_extensions)

    def scan_file(self, file_path: str, content: str) -> List[DetectionResult]:
        """
        扫描单个文件
        
        Args:
            file_path: 文件路径
            content: 文件内容
            
        Returns:
            检测结果列表
        """
        raise NotImplementedError

    def detect(self, source_path: str) -> List[DetectionResult]:
        import os
        results = []
        
        for root, dirs, files in os.walk(source_path):
            for filename in files:
                file_path = os.path.join(root, filename)
                
                if not self.supports_file(file_path):
                    continue
                
                try:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                    
                    file_results = self.scan_file(file_path, content)
                    results.extend(file_results)
                except Exception as e:
                    continue
        
        return results