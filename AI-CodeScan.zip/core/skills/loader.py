import os
import importlib.util
import logging
from typing import Dict, Optional, List
from datetime import datetime

from .models import SkillInfo, SkillManifest


logger = logging.getLogger("SkillLoader")


class SkillLoader:
    """技能加载器"""

    def __init__(self, skills_dir: str = "data/skills"):
        self.skills_dir = skills_dir
        self.loaded_skills: Dict[str, SkillInfo] = {}
        
        os.makedirs(skills_dir, exist_ok=True)

    def load_all_skills(self) -> List[str]:
        """加载所有技能"""
        loaded_ids = []
        
        if not os.path.exists(self.skills_dir):
            return loaded_ids
        
        for skill_dir in os.listdir(self.skills_dir):
            skill_path = os.path.join(self.skills_dir, skill_dir)
            
            if not os.path.isdir(skill_path):
                continue
            
            try:
                skill_info = self.load_skill(skill_path)
                if skill_info:
                    self.loaded_skills[skill_info.manifest.skill_id] = skill_info
                    loaded_ids.append(skill_info.manifest.skill_id)
                    logger.info(f"Loaded skill: {skill_info.manifest.skill_id}")
            except Exception as e:
                logger.error(f"Failed to load skill {skill_dir}: {e}")
        
        return loaded_ids

    def load_skill(self, skill_path: str) -> Optional[SkillInfo]:
        """加载单个技能"""
        manifest_path = os.path.join(skill_path, "skill.yaml")
        
        if not os.path.exists(manifest_path):
            logger.warning(f"Skill manifest not found: {manifest_path}")
            return None
        
        try:
            manifest = SkillManifest.from_yaml(manifest_path)
        except Exception as e:
            logger.error(f"Failed to parse skill manifest: {e}")
            return None
        
        skill_info = SkillInfo(
            manifest=manifest,
            last_loaded_at=datetime.utcnow()
        )
        
        detector_path = os.path.join(skill_path, "detector.py")
        if os.path.exists(detector_path):
            skill_info.detector_path = detector_path
        
        exploit_path = os.path.join(skill_path, "exploit.py")
        if os.path.exists(exploit_path):
            skill_info.exploit_generator_path = exploit_path
        
        waf_path = os.path.join(skill_path, "waf_generator.py")
        if os.path.exists(waf_path):
            skill_info.waf_generator_path = waf_path
        
        remediation_path = os.path.join(skill_path, "remediation.py")
        if os.path.exists(remediation_path):
            skill_info.remediation_path = remediation_path
        
        examples_path = os.path.join(skill_path, "examples")
        if os.path.exists(examples_path):
            skill_info.examples_path = examples_path
        
        skill_info.is_loaded = True
        
        return skill_info

    def get_skill(self, skill_id: str) -> Optional[SkillInfo]:
        """获取已加载的技能"""
        return self.loaded_skills.get(skill_id)

    def get_detector(self, skill_id: str):
        """获取技能的检测器实例"""
        skill_info = self.get_skill(skill_id)
        if not skill_info or not skill_info.detector_path:
            return None
        
        try:
            spec = importlib.util.spec_from_file_location(
                f"skill_{skill_id}_detector",
                skill_info.detector_path
            )
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            
            for name in dir(module):
                obj = getattr(module, name)
                if isinstance(obj, type) and obj.__name__ == "Detector":
                    return obj()
                    
        except Exception as e:
            logger.error(f"Failed to load detector for {skill_id}: {e}")
        
        return None

    def get_exploit_generator(self, skill_id: str, detection_result):
        """获取技能的利用生成器实例"""
        skill_info = self.get_skill(skill_id)
        if not skill_info or not skill_info.exploit_generator_path:
            return None
        
        try:
            spec = importlib.util.spec_from_file_location(
                f"skill_{skill_id}_exploit",
                skill_info.exploit_generator_path
            )
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            
            for name in dir(module):
                obj = getattr(module, name)
                if isinstance(obj, type) and obj.__name__ == "ExploitGenerator":
                    return obj(detection_result)
                    
        except Exception as e:
            logger.error(f"Failed to load exploit generator for {skill_id}: {e}")
        
        return None

    def list_skills(self) -> List[SkillInfo]:
        """获取所有已加载技能列表"""
        return list(self.loaded_skills.values())

    def unload_skill(self, skill_id: str) -> bool:
        """卸载技能"""
        if skill_id in self.loaded_skills:
            del self.loaded_skills[skill_id]
            logger.info(f"Unloaded skill: {skill_id}")
            return True
        return False