import os
import logging
from typing import List, Dict, Optional, Any
from datetime import datetime

from .loader import SkillLoader
from .uploader import SkillUploader
from .models import SkillInfo, SkillManifest, DetectionResult, ExploitScript, PlatformType, SkillCategory


logger = logging.getLogger("SkillManager")


class SkillManager:
    """技能管理器"""

    def __init__(self, skills_dir: str = "data/skills"):
        self.skills_dir = skills_dir
        self.loader = SkillLoader(skills_dir)
        self.uploader = SkillUploader(skills_dir)
        self._initialized = False

    def initialize(self, force_reload: bool = False) -> bool:
        """初始化技能管理器"""
        if self._initialized and not force_reload:
            return True
        
        logger.info("Initializing SkillManager...")
        
        try:
            self.loader.loaded_skills.clear()
            loaded_skills = self.loader.load_all_skills()
            logger.info(f"Loaded {len(loaded_skills)} skills: {loaded_skills}")
            self._initialized = True
            return True
        except Exception as e:
            logger.error(f"Failed to initialize SkillManager: {e}")
            return False

    def upload_skill(self, zip_path: str) -> Optional[str]:
        """上传技能"""
        skill_id = self.uploader.upload_skill(zip_path)
        
        if skill_id:
            self.loader.load_all_skills()
        
        return skill_id

    def create_skill_template(self, skill_id: str, name: str) -> bool:
        """创建技能模板"""
        return self.uploader.create_skill_template(skill_id, name, self.skills_dir)

    def get_skill(self, skill_id: str) -> Optional[SkillInfo]:
        """获取技能信息"""
        return self.loader.get_skill(skill_id)

    def list_skills(self) -> List[SkillInfo]:
        """获取所有技能列表"""
        return self.loader.list_skills()

    def list_skills_by_platform(self, platform: PlatformType) -> List[SkillInfo]:
        """按平台筛选技能"""
        return [
            skill for skill in self.loader.list_skills()
            if platform in skill.manifest.platforms
        ]

    def list_skills_by_category(self, category: SkillCategory) -> List[SkillInfo]:
        """按分类筛选技能"""
        return [
            skill for skill in self.loader.list_skills()
            if skill.manifest.category == category
        ]

    def remove_skill(self, skill_id: str) -> bool:
        """移除技能"""
        import shutil
        
        skill_path = os.path.join(self.skills_dir, skill_id)
        
        if os.path.exists(skill_path):
            shutil.rmtree(skill_path)
            self.loader.unload_skill(skill_id)
            logger.info(f"Removed skill: {skill_id}")
            return True
        
        return False

    def run_detection(self, skill_id: str, source_path: str) -> List[DetectionResult]:
        """执行检测"""
        detector = self.loader.get_detector(skill_id)
        
        if not detector:
            logger.error(f"Detector not found for skill: {skill_id}")
            return []
        
        try:
            results = detector.detect(source_path)
            logger.info(f"Detection completed for {skill_id}: {len(results)} findings")
            return results
        except Exception as e:
            logger.error(f"Detection failed for {skill_id}: {e}")
            return []

    def generate_exploit(self, skill_id: str, detection_result: DetectionResult) -> List[ExploitScript]:
        """生成利用脚本"""
        generator = self.loader.get_exploit_generator(skill_id, detection_result)
        
        if not generator:
            logger.error(f"Exploit generator not found for skill: {skill_id}")
            return []
        
        try:
            scripts = generator.generate()
            logger.info(f"Generated {len(scripts)} exploit scripts for {skill_id}")
            return scripts
        except Exception as e:
            logger.error(f"Exploit generation failed for {skill_id}: {e}")
            return []

    def run_all_detections(self, source_path: str, platform: PlatformType = PlatformType.WEB) -> Dict[str, List[DetectionResult]]:
        """运行所有适用于指定平台的检测"""
        results = {}
        
        skills = self.list_skills_by_platform(platform)
        
        for skill in skills:
            skill_results = self.run_detection(skill.manifest.skill_id, source_path)
            if skill_results:
                results[skill.manifest.skill_id] = skill_results
        
        return results

    def get_skill_metadata(self) -> List[Dict[str, Any]]:
        """获取所有技能的元数据"""
        metadata = []
        
        for skill in self.loader.list_skills():
            metadata.append({
                "skill_id": skill.manifest.skill_id,
                "name": skill.manifest.name,
                "version": skill.manifest.version,
                "author": skill.manifest.author,
                "category": skill.manifest.category.value,
                "platforms": [p.value for p in skill.manifest.platforms],
                "languages": skill.manifest.supported_languages,
                "is_loaded": skill.is_loaded,
                "last_loaded_at": skill.last_loaded_at.isoformat() if skill.last_loaded_at else None
            })
        
        return metadata

    def export_skill(self, skill_id: str, output_path: str) -> bool:
        """导出技能为压缩包"""
        import zipfile
        
        skill_info = self.loader.get_skill(skill_id)
        if not skill_info:
            return False
        
        skill_dir = os.path.join(self.skills_dir, skill_id)
        
        try:
            with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for root, dirs, files in os.walk(skill_dir):
                    for file in files:
                        file_path = os.path.join(root, file)
                        arcname = os.path.relpath(file_path, self.skills_dir)
                        zipf.write(file_path, arcname)
            
            logger.info(f"Skill exported to: {output_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to export skill: {e}")
            return False