from datetime import datetime
from enum import Enum
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field


class SkillCategory(str, Enum):
    WEB_SECURITY = "web-security"
    BINARY_SECURITY = "binary-security"
    CRYPTO_SECURITY = "crypto-security"
    CONFIG_SECURITY = "config-security"
    FRAMEWORK_SECURITY = "framework-security"


class PlatformType(str, Enum):
    WEB = "web"
    CS = "cs"
    CLIENT = "client"
    APP = "app"


class SeverityLevel(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class SkillManifest(BaseModel):
    skill_id: str = Field(..., description="Skill唯一标识")
    name: str = Field(..., description="Skill名称")
    version: str = Field("1.0.0", description="版本号")
    author: str = Field(..., description="作者")
    description: str = Field(..., description="描述")
    category: SkillCategory = Field(..., description="分类")
    platforms: List[PlatformType] = Field(default_factory=list, description="支持的平台")
    supported_languages: List[str] = Field(default_factory=list, description="支持的语言")
    vulnerability: Dict[str, Any] = Field(default_factory=dict, description="漏洞信息")
    execution: Dict[str, Any] = Field(default_factory=dict, description="执行配置")
    dependencies: List[str] = Field(default_factory=list, description="依赖技能")
    created_at: datetime = Field(default_factory=datetime.utcnow, description="创建时间")
    updated_at: datetime = Field(default_factory=datetime.utcnow, description="更新时间")

    @classmethod
    def from_yaml(cls, yaml_path: str) -> "SkillManifest":
        import yaml
        with open(yaml_path, 'r', encoding='utf-8', errors='replace') as f:
            data = yaml.safe_load(f)
        return cls(**data)


class DetectionResult(BaseModel):
    found: bool = Field(..., description="是否发现漏洞")
    file_path: str = Field(..., description="文件路径")
    line: int = Field(..., description="行号")
    column: int = Field(..., description="列号")
    code_snippet: str = Field(..., description="代码片段")
    vulnerability_type: str = Field(..., description="漏洞类型")
    severity: SeverityLevel = Field(..., description="严重程度")
    confidence: float = Field(..., ge=0.0, le=1.0, description="置信度")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="元数据")


class ExploitScript(BaseModel):
    name: str = Field(..., description="脚本名称")
    language: str = Field(..., description="编程语言")
    code: str = Field(..., description="脚本代码")
    description: str = Field(..., description="描述")
    requirements: List[str] = Field(default_factory=list, description="依赖")
    parameters: Dict[str, Any] = Field(default_factory=dict, description="参数")
    success_indicators: List[str] = Field(default_factory=list, description="成功指标")


class SkillInfo(BaseModel):
    manifest: SkillManifest = Field(..., description="技能清单")
    detector_path: Optional[str] = Field(None, description="检测器路径")
    exploit_generator_path: Optional[str] = Field(None, description="利用生成器路径")
    waf_generator_path: Optional[str] = Field(None, description="WAF规则生成器路径")
    remediation_path: Optional[str] = Field(None, description="整改建议生成器路径")
    examples_path: Optional[str] = Field(None, description="示例路径")
    is_loaded: bool = Field(False, description="是否已加载")
    last_loaded_at: Optional[datetime] = Field(None, description="最后加载时间")