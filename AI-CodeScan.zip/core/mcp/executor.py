import asyncio
import uuid
import logging
from typing import Dict, List, Optional, Any

from .adapter import MCPClient, ShellCommandAdapter, PythonScriptAdapter, HTTPRequestAdapter
from .models import MCPToolInfo, ExecutionResult, ToolCategory


logger = logging.getLogger("MCPExecutor")


class MCPExecutor:
    """MCP工具执行器"""

    def __init__(self):
        self.client = MCPClient()
        self._register_default_tools()

    def _register_default_tools(self) -> None:
        """注册默认工具"""
        shell_tool = MCPToolInfo(
            tool_id="shell-command",
            name="Shell命令执行器",
            description="执行Shell命令",
            category=ToolCategory.UTILITIES,
            author="DeepAudit",
            supported_platforms=["linux", "windows"],
            parameters=[
                {"name": "command", "type": "string", "required": True, "description": "要执行的命令"},
                {"name": "working_dir", "type": "string", "required": False, "description": "工作目录"},
                {"name": "timeout", "type": "integer", "required": False, "description": "超时时间"}
            ],
            timeout=300
        )
        self.client.register_adapter(ShellCommandAdapter(shell_tool))

        python_tool = MCPToolInfo(
            tool_id="python-script",
            name="Python脚本执行器",
            description="执行Python脚本",
            category=ToolCategory.UTILITIES,
            author="DeepAudit",
            supported_platforms=["linux", "windows"],
            parameters=[
                {"name": "script", "type": "string", "required": True, "description": "Python脚本代码"},
                {"name": "working_dir", "type": "string", "required": False, "description": "工作目录"},
                {"name": "timeout", "type": "integer", "required": False, "description": "超时时间"}
            ],
            timeout=300
        )
        self.client.register_adapter(PythonScriptAdapter(python_tool))

        http_tool = MCPToolInfo(
            tool_id="http-request",
            name="HTTP请求工具",
            description="发送HTTP请求",
            category=ToolCategory.UTILITIES,
            author="DeepAudit",
            supported_platforms=["linux", "windows"],
            parameters=[
                {"name": "url", "type": "string", "required": True, "description": "目标URL"},
                {"name": "method", "type": "string", "required": False, "description": "HTTP方法"},
                {"name": "headers", "type": "object", "required": False, "description": "请求头"},
                {"name": "data", "type": "object", "required": False, "description": "请求数据"},
                {"name": "params", "type": "object", "required": False, "description": "查询参数"},
                {"name": "timeout", "type": "integer", "required": False, "description": "超时时间"}
            ],
            timeout=30
        )
        self.client.register_adapter(HTTPRequestAdapter(http_tool))

        logger.info("Registered default MCP tools")

    async def execute(self, tool_id: str, **kwargs) -> ExecutionResult:
        """执行工具"""
        logger.info(f"Executing MCP tool: {tool_id}")
        result = await self.client.execute_tool(tool_id, **kwargs)
        logger.info(f"Tool execution completed: {tool_id}, status: {result.status}")
        return result

    async def execute_shell_command(self, command: str, working_dir: str = ".", timeout: int = 300) -> ExecutionResult:
        """执行Shell命令"""
        return await self.execute(
            "shell-command",
            command=command,
            working_dir=working_dir,
            timeout=timeout
        )

    async def execute_python_script(self, script: str, working_dir: str = ".", timeout: int = 300) -> ExecutionResult:
        """执行Python脚本"""
        return await self.execute(
            "python-script",
            script=script,
            working_dir=working_dir,
            timeout=timeout
        )

    async def send_http_request(self, url: str, method: str = "GET", **kwargs) -> ExecutionResult:
        """发送HTTP请求"""
        return await self.execute(
            "http-request",
            url=url,
            method=method,
            **kwargs
        )

    def list_tools(self) -> List[MCPToolInfo]:
        """获取所有工具列表"""
        return self.client.list_tools()

    def get_tool_info(self, tool_id: str) -> Optional[MCPToolInfo]:
        """获取工具信息"""
        return self.client.get_tool_info(tool_id)

    async def run_build_command(self, project_path: str, build_command: str) -> ExecutionResult:
        """运行构建命令"""
        logger.info(f"Building project at: {project_path}")
        return await self.execute_shell_command(build_command, working_dir=project_path)

    async def run_test_command(self, project_path: str, test_command: str) -> ExecutionResult:
        """运行测试命令"""
        logger.info(f"Running tests at: {project_path}")
        return await self.execute_shell_command(test_command, working_dir=project_path)


class TaskManager:
    """任务管理器"""

    def __init__(self):
        self.tasks: Dict[str, ExecutionResult] = {}
        self.executor = MCPExecutor()

    async def submit_task(self, tool_id: str, **kwargs) -> str:
        """提交任务"""
        task_id = str(uuid.uuid4())
        
        async def run_task():
            result = await self.executor.execute(tool_id, task_id=task_id, **kwargs)
            self.tasks[task_id] = result
            return result
        
        asyncio.create_task(run_task())
        
        logger.info(f"Submitted task: {task_id} -> {tool_id}")
        return task_id

    def get_task_result(self, task_id: str) -> Optional[ExecutionResult]:
        """获取任务结果"""
        return self.tasks.get(task_id)

    def list_tasks(self) -> List[str]:
        """获取所有任务ID"""
        return list(self.tasks.keys())

    async def execute_sync(self, tool_id: str, **kwargs) -> ExecutionResult:
        """同步执行任务"""
        return await self.executor.execute(tool_id, **kwargs)