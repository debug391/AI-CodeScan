import os
import shutil
import tempfile
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime

from .models import EnvironmentInfo, ExecutionResult, ExecutionStatus
from .executor import MCPExecutor


logger = logging.getLogger("EnvironmentSimulator")


class EnvironmentSimulator:
    """环境模拟器 - 提供模拟构建和运行环境"""

    def __init__(self):
        self.executor = MCPExecutor()
        self.environments: Dict[str, EnvironmentInfo] = {}
        self.temp_dirs: Dict[str, str] = {}

    async def create_environment(self, name: str, platform: str = "web") -> EnvironmentInfo:
        """创建模拟环境"""
        env_id = f"env-{name.lower().replace(' ', '-')}"
        
        if env_id in self.environments:
            return self.environments[env_id]

        temp_dir = tempfile.mkdtemp(prefix=f"audit_env_{name}_")
        self.temp_dirs[env_id] = temp_dir

        env_info = EnvironmentInfo(
            name=name,
            type="virtual",
            status="running",
            platform=platform,
            version="1.0",
            created_at=datetime.utcnow()
        )
        
        self.environments[env_id] = env_info
        logger.info(f"Created environment: {env_id} at {temp_dir}")
        
        return env_info

    async def destroy_environment(self, env_id: str) -> bool:
        """销毁环境"""
        if env_id not in self.environments:
            return False

        temp_dir = self.temp_dirs.get(env_id)
        if temp_dir and os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)
            del self.temp_dirs[env_id]

        del self.environments[env_id]
        logger.info(f"Destroyed environment: {env_id}")
        
        return True

    async def copy_project(self, env_id: str, source_path: str) -> bool:
        """复制项目到环境"""
        if env_id not in self.environments:
            return False

        target_dir = self.temp_dirs.get(env_id)
        if not target_dir:
            return False

        try:
            project_dir = os.path.join(target_dir, "project")
            
            if os.path.exists(project_dir):
                shutil.rmtree(project_dir)
            
            if os.path.isdir(source_path):
                shutil.copytree(source_path, project_dir)
            else:
                os.makedirs(project_dir)
                shutil.copy2(source_path, project_dir)
            
            logger.info(f"Copied project to environment {env_id}: {source_path} -> {project_dir}")
            return True
        
        except Exception as e:
            logger.error(f"Failed to copy project: {e}")
            return False

    async def run_build(self, env_id: str, build_command: str) -> ExecutionResult:
        """在环境中运行构建命令"""
        if env_id not in self.environments:
            return ExecutionResult(
                tool_id="env-build",
                task_id=env_id,
                status=ExecutionStatus.FAILED,
                error=f"Environment not found: {env_id}",
                return_code=-1
            )

        project_dir = os.path.join(self.temp_dirs[env_id], "project")
        
        logger.info(f"Building project in environment {env_id}: {build_command}")
        result = await self.executor.execute_shell_command(build_command, working_dir=project_dir)
        
        return result

    async def run_poc(self, env_id: str, script_content: str, language: str = "python") -> ExecutionResult:
        """在环境中运行POC脚本"""
        if env_id not in self.environments:
            return ExecutionResult(
                tool_id="env-poc",
                task_id=env_id,
                status=ExecutionStatus.FAILED,
                error=f"Environment not found: {env_id}",
                return_code=-1
            )

        working_dir = self.temp_dirs[env_id]
        
        logger.info(f"Running POC in environment {env_id}")
        
        if language.lower() == "python":
            result = await self.executor.execute_python_script(script_content, working_dir=working_dir)
        else:
            script_path = os.path.join(working_dir, "poc.sh")
            with open(script_path, 'w') as f:
                f.write(script_content)
            
            result = await self.executor.execute_shell_command(f"bash {script_path}", working_dir=working_dir)
            os.remove(script_path)
        
        return result

    async def start_service(self, env_id: str, service_command: str, port: int = 8000) -> ExecutionResult:
        """启动服务"""
        if env_id not in self.environments:
            return ExecutionResult(
                tool_id="env-start",
                task_id=env_id,
                status=ExecutionStatus.FAILED,
                error=f"Environment not found: {env_id}",
                return_code=-1
            )

        project_dir = os.path.join(self.temp_dirs[env_id], "project")
        
        logger.info(f"Starting service in environment {env_id} on port {port}")
        
        env_info = self.environments[env_id]
        env_info.ports[port] = port
        env_info.status = "running"
        
        result = await self.executor.execute_shell_command(service_command, working_dir=project_dir)
        
        return result

    async def stop_service(self, env_id: str) -> bool:
        """停止服务"""
        if env_id not in self.environments:
            return False

        env_info = self.environments[env_id]
        env_info.status = "stopped"
        env_info.ports.clear()
        
        logger.info(f"Stopped service in environment {env_id}")
        return True

    def get_environment(self, env_id: str) -> Optional[EnvironmentInfo]:
        """获取环境信息"""
        return self.environments.get(env_id)

    def list_environments(self) -> List[EnvironmentInfo]:
        """获取所有环境列表"""
        return list(self.environments.values())

    async def verify_vulnerability(self, source_path: str, script_content: str, 
                                  language: str = "python", build_command: str = None) -> ExecutionResult:
        """完整的漏洞验证流程"""
        env_name = f"verify-{hash(source_path) % 10000}"
        env_id = await self.create_environment(env_name)
        
        try:
            await self.copy_project(env_id.env_id if hasattr(env_id, 'env_id') else env_name, source_path)
            
            if build_command:
                build_result = await self.run_build(env_id.env_id if hasattr(env_id, 'env_id') else env_name, build_command)
                if not build_result.is_success():
                    logger.warning(f"Build failed, continuing with verification")
            
            result = await self.run_poc(env_id.env_id if hasattr(env_id, 'env_id') else env_name, script_content, language)
            
            return result
        
        finally:
            await self.destroy_environment(env_id.env_id if hasattr(env_id, 'env_id') else env_name)