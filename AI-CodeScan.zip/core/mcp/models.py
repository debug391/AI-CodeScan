from datetime import datetime
from enum import Enum
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field


class ToolCategory(str, Enum):
    CODE_ANALYSIS = "code-analysis"
    BUILD_TOOLS = "build-tools"
    ENVIRONMENT = "environment"
    SECURITY_TOOLS = "security-tools"
    UTILITIES = "utilities"


class ExecutionStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    TIMEOUT = "timeout"


class MCPToolInfo(BaseModel):
    tool_id: str = Field(..., description="工具唯一标识")
    name: str = Field(..., description="工具名称")
    description: str = Field(..., description="工具描述")
    category: ToolCategory = Field(..., description="工具分类")
    version: str = Field("1.0.0", description="版本号")
    author: str = Field(..., description="作者")
    supported_platforms: List[str] = Field(default_factory=list, description="支持的平台")
    parameters: List[Dict[str, Any]] = Field(default_factory=list, description="参数定义")
    requires_env: bool = Field(False, description="是否需要特定环境")
    timeout: int = Field(300, description="超时时间（秒）")
    is_available: bool = Field(True, description="是否可用")


class ExecutionResult(BaseModel):
    tool_id: str = Field(..., description="执行的工具ID")
    task_id: str = Field(..., description="任务ID")
    status: ExecutionStatus = Field(..., description="执行状态")
    output: str = Field("", description="标准输出")
    error: str = Field("", description="错误输出")
    return_code: int = Field(0, description="返回码")
    execution_time: float = Field(0.0, description="执行时间（秒）")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="时间戳")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="元数据")
    files_generated: List[str] = Field(default_factory=list, description="生成的文件列表")

    def is_success(self) -> bool:
        return self.status == ExecutionStatus.COMPLETED and self.return_code == 0

    def get_summary(self) -> str:
        summary = f"Tool: {self.tool_id}\nStatus: {self.status.value}\n"
        if self.output:
            summary += f"Output: {self.output[:500]}..." if len(self.output) > 500 else f"Output: {self.output}"
        if self.error:
            summary += f"\nError: {self.error[:200]}..." if len(self.error) > 200 else f"\nError: {self.error}"
        summary += f"\nExecution Time: {self.execution_time:.2f}s"
        return summary


class EnvironmentInfo(BaseModel):
    name: str = Field(..., description="环境名称")
    type: str = Field(..., description="环境类型: docker/virtual/host")
    status: str = Field("stopped", description="状态: running/stopped")
    platform: str = Field("", description="平台类型")
    version: str = Field("", description="环境版本")
    ports: Dict[int, int] = Field(default_factory=dict, description="端口映射")
    volumes: Dict[str, str] = Field(default_factory=dict, description="卷挂载")
    environment_vars: Dict[str, str] = Field(default_factory=dict, description="环境变量")
    created_at: datetime = Field(default_factory=datetime.utcnow, description="创建时间")