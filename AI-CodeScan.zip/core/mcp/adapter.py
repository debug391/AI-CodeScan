import json
import uuid
import logging
from typing import Dict, List, Optional, Any
from abc import ABC, abstractmethod

from .models import MCPToolInfo, ExecutionResult, ExecutionStatus


logger = logging.getLogger("MCPAdapter")


class BaseMCPAdapter(ABC):
    """MCP工具适配器基类"""

    def __init__(self, tool_info: MCPToolInfo):
        self.tool_info = tool_info
        self.logger = logging.getLogger(f"MCPAdapter.{tool_info.tool_id}")

    @abstractmethod
    async def execute(self, task_id: str, **kwargs) -> ExecutionResult:
        """执行工具"""
        pass

    def get_tool_info(self) -> MCPToolInfo:
        """获取工具信息"""
        return self.tool_info


class ShellCommandAdapter(BaseMCPAdapter):
    """Shell命令工具适配器"""

    async def execute(self, task_id: str, **kwargs) -> ExecutionResult:
        import subprocess
        import shlex
        import time
        
        command = kwargs.get("command", "")
        working_dir = kwargs.get("working_dir", ".")
        timeout = kwargs.get("timeout", self.tool_info.timeout)
        
        self.logger.info(f"Executing command: {command}")
        
        start_time = time.time()
        
        try:
            result = subprocess.run(
                shlex.split(command),
                cwd=working_dir,
                capture_output=True,
                text=True,
                timeout=timeout
            )
            
            execution_time = time.time() - start_time
            
            status = ExecutionStatus.COMPLETED if result.returncode == 0 else ExecutionStatus.FAILED
            
            return ExecutionResult(
                tool_id=self.tool_info.tool_id,
                task_id=task_id,
                status=status,
                output=result.stdout,
                error=result.stderr,
                return_code=result.returncode,
                execution_time=execution_time
            )
        
        except subprocess.TimeoutExpired:
            execution_time = time.time() - start_time
            return ExecutionResult(
                tool_id=self.tool_info.tool_id,
                task_id=task_id,
                status=ExecutionStatus.TIMEOUT,
                output="",
                error="Command timed out",
                return_code=-1,
                execution_time=execution_time
            )
        except Exception as e:
            execution_time = time.time() - start_time
            return ExecutionResult(
                tool_id=self.tool_info.tool_id,
                task_id=task_id,
                status=ExecutionStatus.FAILED,
                output="",
                error=str(e),
                return_code=-1,
                execution_time=execution_time
            )


class PythonScriptAdapter(BaseMCPAdapter):
    """Python脚本工具适配器"""

    async def execute(self, task_id: str, **kwargs) -> ExecutionResult:
        import subprocess
        import tempfile
        import os
        import time
        
        script_code = kwargs.get("script", "")
        working_dir = kwargs.get("working_dir", ".")
        timeout = kwargs.get("timeout", self.tool_info.timeout)
        
        self.logger.info(f"Executing Python script (length: {len(script_code)} chars)")
        
        start_time = time.time()
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
            f.write(script_code)
            script_path = f.name
        
        try:
            result = subprocess.run(
                ["python3", script_path],
                cwd=working_dir,
                capture_output=True,
                text=True,
                timeout=timeout
            )
            
            execution_time = time.time() - start_time
            
            status = ExecutionStatus.COMPLETED if result.returncode == 0 else ExecutionStatus.FAILED
            
            return ExecutionResult(
                tool_id=self.tool_info.tool_id,
                task_id=task_id,
                status=status,
                output=result.stdout,
                error=result.stderr,
                return_code=result.returncode,
                execution_time=execution_time
            )
        
        except subprocess.TimeoutExpired:
            execution_time = time.time() - start_time
            return ExecutionResult(
                tool_id=self.tool_info.tool_id,
                task_id=task_id,
                status=ExecutionStatus.TIMEOUT,
                output="",
                error="Script timed out",
                return_code=-1,
                execution_time=execution_time
            )
        except Exception as e:
            execution_time = time.time() - start_time
            return ExecutionResult(
                tool_id=self.tool_info.tool_id,
                task_id=task_id,
                status=ExecutionStatus.FAILED,
                output="",
                error=str(e),
                return_code=-1,
                execution_time=execution_time
            )
        finally:
            os.unlink(script_path)


class HTTPRequestAdapter(BaseMCPAdapter):
    """HTTP请求工具适配器"""

    async def execute(self, task_id: str, **kwargs) -> ExecutionResult:
        import requests
        import time
        
        url = kwargs.get("url", "")
        method = kwargs.get("method", "GET").upper()
        headers = kwargs.get("headers", {})
        data = kwargs.get("data", {})
        params = kwargs.get("params", {})
        timeout = kwargs.get("timeout", 30)
        
        self.logger.info(f"Executing HTTP {method} request to: {url}")
        
        start_time = time.time()
        
        try:
            if method == "GET":
                response = requests.get(url, headers=headers, params=params, timeout=timeout)
            elif method == "POST":
                response = requests.post(url, headers=headers, data=data, timeout=timeout)
            elif method == "PUT":
                response = requests.put(url, headers=headers, data=data, timeout=timeout)
            elif method == "DELETE":
                response = requests.delete(url, headers=headers, timeout=timeout)
            else:
                return ExecutionResult(
                    tool_id=self.tool_info.tool_id,
                    task_id=task_id,
                    status=ExecutionStatus.FAILED,
                    output="",
                    error=f"Unsupported HTTP method: {method}",
                    return_code=-1,
                    execution_time=0
                )
            
            execution_time = time.time() - start_time
            
            output = json.dumps({
                "status_code": response.status_code,
                "headers": dict(response.headers),
                "content": response.text[:2000] if len(response.text) > 2000 else response.text
            }, indent=2)
            
            status = ExecutionStatus.COMPLETED if 200 <= response.status_code < 400 else ExecutionStatus.FAILED
            
            return ExecutionResult(
                tool_id=self.tool_info.tool_id,
                task_id=task_id,
                status=status,
                output=output,
                error="",
                return_code=response.status_code,
                execution_time=execution_time
            )
        
        except requests.exceptions.Timeout:
            execution_time = time.time() - start_time
            return ExecutionResult(
                tool_id=self.tool_info.tool_id,
                task_id=task_id,
                status=ExecutionStatus.TIMEOUT,
                output="",
                error="HTTP request timed out",
                return_code=-1,
                execution_time=execution_time
            )
        except Exception as e:
            execution_time = time.time() - start_time
            return ExecutionResult(
                tool_id=self.tool_info.tool_id,
                task_id=task_id,
                status=ExecutionStatus.FAILED,
                output="",
                error=str(e),
                return_code=-1,
                execution_time=execution_time
            )


class MCPClient:
    """MCP客户端"""

    def __init__(self):
        self.adapters: Dict[str, BaseMCPAdapter] = {}

    def register_adapter(self, adapter: BaseMCPAdapter) -> None:
        """注册适配器"""
        self.adapters[adapter.tool_info.tool_id] = adapter
        logger.info(f"Registered MCP adapter: {adapter.tool_info.tool_id}")

    def get_adapter(self, tool_id: str) -> Optional[BaseMCPAdapter]:
        """获取适配器"""
        return self.adapters.get(tool_id)

    async def execute_tool(self, tool_id: str, **kwargs) -> ExecutionResult:
        """执行工具"""
        adapter = self.get_adapter(tool_id)
        
        if not adapter:
            return ExecutionResult(
                tool_id=tool_id,
                task_id=str(uuid.uuid4()),
                status=ExecutionStatus.FAILED,
                output="",
                error=f"Tool not found: {tool_id}",
                return_code=-1,
                execution_time=0
            )
        
        task_id = kwargs.get("task_id", str(uuid.uuid4()))
        return await adapter.execute(task_id, **kwargs)

    def list_tools(self) -> List[MCPToolInfo]:
        """获取所有工具列表"""
        return [adapter.tool_info for adapter in self.adapters.values()]

    def get_tool_info(self, tool_id: str) -> Optional[MCPToolInfo]:
        """获取工具信息"""
        adapter = self.get_adapter(tool_id)
        return adapter.tool_info if adapter else None