from datetime import datetime
from enum import Enum
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field


class VulnerabilitySeverity(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class VulnerabilityStatus(str, Enum):
    DETECTED = "detected"
    VERIFIED = "verified"
    FALSE_POSITIVE = "false_positive"
    FIXED = "fixed"


class VulnerabilityRecord(BaseModel):
    vulnerability_id: str = Field(..., description="漏洞唯一标识")
    type: str = Field(..., description="漏洞类型")
    cwe: str = Field("", description="CWE编号")
    severity: VulnerabilitySeverity = Field(VulnerabilitySeverity.MEDIUM, description="严重程度")
    status: VulnerabilityStatus = Field(VulnerabilityStatus.DETECTED, description="状态")
    file_path: str = Field(..., description="文件路径")
    line: int = Field(0, description="行号")
    column: int = Field(0, description="列号")
    code_snippet: str = Field("", description="代码片段")
    description: str = Field("", description="漏洞描述")
    attack_vector: str = Field("", description="攻击向量")
    impact: str = Field("", description="影响范围")
    exploit_script: str = Field("", description="利用脚本路径")
    waf_rules: List[str] = Field(default_factory=list, description="WAF规则")
    remediation: str = Field("", description="整改建议")
    confidence: float = Field(0.0, description="置信度")
    discovered_at: datetime = Field(default_factory=datetime.utcnow, description="发现时间")
    verified_at: Optional[datetime] = Field(None, description="验证时间")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="元数据")

    def to_dict(self) -> Dict[str, Any]:
        return {
            "vulnerability_id": self.vulnerability_id,
            "type": self.type,
            "cwe": self.cwe,
            "severity": self.severity.value,
            "status": self.status.value,
            "file_path": self.file_path,
            "line": self.line,
            "column": self.column,
            "code_snippet": self.code_snippet,
            "description": self.description,
            "attack_vector": self.attack_vector,
            "impact": self.impact,
            "exploit_script": self.exploit_script,
            "waf_rules": self.waf_rules,
            "remediation": self.remediation,
            "confidence": self.confidence,
            "discovered_at": self.discovered_at.isoformat(),
            "verified_at": self.verified_at.isoformat() if self.verified_at else None,
            "metadata": self.metadata
        }


class AuditThought(BaseModel):
    step_number: int = Field(..., description="步骤编号")
    title: str = Field(..., description="步骤标题")
    description: str = Field("", description="详细描述")
    code_context: str = Field("", description="代码上下文")
    analysis: str = Field("", description="分析内容")
    findings: List[str] = Field(default_factory=list, description="发现项")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="时间戳")

    def to_dict(self) -> Dict[str, Any]:
        return {
            "step_number": self.step_number,
            "title": self.title,
            "description": self.description,
            "code_context": self.code_context,
            "analysis": self.analysis,
            "findings": self.findings,
            "timestamp": self.timestamp.isoformat()
        }


class AuditResult(BaseModel):
    task_id: str = Field(..., description="任务ID")
    project_id: str = Field(..., description="项目ID")
    project_name: str = Field(..., description="项目名称")
    source_path: str = Field(..., description="源码路径")
    status: str = Field("running", description="状态")
    platform: str = Field("web", description="平台")
    vulnerabilities: List[VulnerabilityRecord] = Field(default_factory=list, description="漏洞列表")
    audit_thoughts: List[AuditThought] = Field(default_factory=list, description="审计思路")
    started_at: datetime = Field(default_factory=datetime.utcnow, description="开始时间")
    completed_at: Optional[datetime] = Field(None, description="完成时间")
    execution_time: float = Field(0.0, description="执行时间")
    summary: Dict[str, Any] = Field(default_factory=dict, description="摘要")

    def add_vulnerability(self, vulnerability: VulnerabilityRecord) -> None:
        self.vulnerabilities.append(vulnerability)

    def add_thought(self, thought: AuditThought) -> None:
        self.audit_thoughts.append(thought)

    def get_summary(self) -> Dict[str, Any]:
        severity_counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}
        
        for vuln in self.vulnerabilities:
            severity_counts[vuln.severity.value] += 1
        
        return {
            "total_vulnerabilities": len(self.vulnerabilities),
            "vulnerability_count": len(self.vulnerabilities),
            "severity_counts": severity_counts,
            "status": self.status,
            "execution_time": self.execution_time,
            "project_name": self.project_name,
            "timestamp": self.completed_at.isoformat() if self.completed_at else self.started_at.isoformat()
        }

    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "project_id": self.project_id,
            "project_name": self.project_name,
            "source_path": self.source_path,
            "status": self.status,
            "platform": self.platform,
            "vulnerabilities": [v.to_dict() for v in self.vulnerabilities],
            "audit_thoughts": [t.to_dict() for t in self.audit_thoughts],
            "started_at": self.started_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "execution_time": self.execution_time,
            "summary": self.get_summary()
        }