import os
import json
import shutil
import logging
from datetime import datetime
from typing import Dict, List, Optional, Any

from .models import AuditResult, VulnerabilityRecord, AuditThought, VulnerabilitySeverity, VulnerabilityStatus


logger = logging.getLogger("ResultStore")


class ResultStore:
    """结果存储管理器"""

    def __init__(self, base_dir: str = "data/audit_results"):
        self.base_dir = base_dir
        os.makedirs(base_dir, exist_ok=True)

    def save_result(self, result: AuditResult) -> str:
        """保存审计结果到指定目录"""
        task_dir = os.path.join(self.base_dir, result.task_id)
        os.makedirs(task_dir, exist_ok=True)

        result_path = os.path.join(task_dir, "result.json")
        with open(result_path, 'w', encoding='utf-8') as f:
            json.dump(result.to_dict(), f, indent=2, ensure_ascii=False)

        self._save_vulnerabilities(task_dir, result.vulnerabilities)
        self._save_audit_thoughts(task_dir, result.audit_thoughts)
        self._save_exploits(task_dir, result.vulnerabilities)
        self._save_waf_rules(task_dir, result.vulnerabilities)
        self._save_report(task_dir, result)

        logger.info(f"Audit result saved to: {task_dir}")
        return task_dir

    def _save_vulnerabilities(self, task_dir: str, vulnerabilities: List[VulnerabilityRecord]) -> None:
        """保存漏洞列表"""
        vuln_dir = os.path.join(task_dir, "vulnerabilities")
        os.makedirs(vuln_dir, exist_ok=True)

        for vuln in vulnerabilities:
            vuln_path = os.path.join(vuln_dir, f"{vuln.vulnerability_id}.json")
            with open(vuln_path, 'w', encoding='utf-8') as f:
                json.dump(vuln.to_dict(), f, indent=2, ensure_ascii=False)

    def _save_audit_thoughts(self, task_dir: str, thoughts: List[AuditThought]) -> None:
        """保存审计思路"""
        thoughts_path = os.path.join(task_dir, "audit_thoughts.md")
        
        with open(thoughts_path, 'w', encoding='utf-8') as f:
            f.write(f"# 审计思路记录\n\n")
            f.write(f"## 项目: {task_dir.split('/')[-1]}\n")
            f.write(f"生成时间: {datetime.utcnow().isoformat()}\n\n")
            
            for thought in thoughts:
                f.write(f"---\n\n")
                f.write(f"## 步骤 {thought.step_number}: {thought.title}\n\n")
                if thought.description:
                    f.write(f"{thought.description}\n\n")
                if thought.code_context:
                    f.write(f"### 代码上下文\n\n```python\n{thought.code_context}\n```\n\n")
                if thought.analysis:
                    f.write(f"### 分析\n\n{thought.analysis}\n\n")
                if thought.findings:
                    f.write(f"### 发现\n\n")
                    for finding in thought.findings:
                        f.write(f"- {finding}\n")
                f.write(f"\n*时间戳: {thought.timestamp.isoformat()}*\n")

    def _save_exploits(self, task_dir: str, vulnerabilities: List[VulnerabilityRecord]) -> None:
        """保存利用脚本"""
        exploits_dir = os.path.join(task_dir, "exploits")
        os.makedirs(exploits_dir, exist_ok=True)

        for vuln in vulnerabilities:
            if vuln.exploit_script:
                script_name = f"{vuln.vulnerability_id}_exploit.py"
                script_path = os.path.join(exploits_dir, script_name)
                with open(script_path, 'w', encoding='utf-8') as f:
                    f.write(vuln.exploit_script)

    def _save_waf_rules(self, task_dir: str, vulnerabilities: List[VulnerabilityRecord]) -> None:
        """保存WAF规则"""
        waf_dir = os.path.join(task_dir, "waf_rules")
        os.makedirs(waf_dir, exist_ok=True)

        modsec_rules = []
        nginx_rules = []

        for vuln in vulnerabilities:
            for rule in vuln.waf_rules:
                if rule.startswith("SecRule"):
                    modsec_rules.append(rule)
                elif rule.startswith("if"):
                    nginx_rules.append(rule)

        if modsec_rules:
            with open(os.path.join(waf_dir, "modsecurity.conf"), 'w', encoding='utf-8') as f:
                f.write("\n".join(modsec_rules))

        if nginx_rules:
            with open(os.path.join(waf_dir, "nginx.conf"), 'w', encoding='utf-8') as f:
                f.write("\n".join(nginx_rules))

    def _save_report(self, task_dir: str, result: AuditResult) -> None:
        """生成报告"""
        report_path = os.path.join(task_dir, "report.md")
        
        summary = result.get_summary()
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(f"# 代码安全审计报告\n\n")
            f.write(f"## 项目信息\n\n")
            f.write(f"- 项目名称: {result.project_name}\n")
            f.write(f"- 项目ID: {result.project_id}\n")
            f.write(f"- 任务ID: {result.task_id}\n")
            f.write(f"- 源码路径: {result.source_path}\n")
            f.write(f"- 平台类型: {result.platform}\n")
            f.write(f"- 审计状态: {result.status}\n")
            f.write(f"- 执行时间: {result.execution_time:.2f} 秒\n")
            f.write(f"- 生成时间: {datetime.utcnow().isoformat()}\n\n")

            f.write(f"## 漏洞统计\n\n")
            f.write(f"- 总漏洞数: {summary['total_vulnerabilities']}\n")
            f.write(f"- Critical: {summary['severity_counts']['critical']}\n")
            f.write(f"- High: {summary['severity_counts']['high']}\n")
            f.write(f"- Medium: {summary['severity_counts']['medium']}\n")
            f.write(f"- Low: {summary['severity_counts']['low']}\n\n")

            f.write(f"## 漏洞详情\n\n")
            for vuln in result.vulnerabilities:
                f.write(f"---\n\n")
                f.write(f"### [{vuln.vulnerability_id}] {vuln.type}\n\n")
                f.write(f"**严重程度:** {vuln.severity.value.upper()}\n")
                f.write(f"**状态:** {vuln.status.value}\n")
                f.write(f"**位置:** {vuln.file_path}:{vuln.line}\n")
                if vuln.cwe:
                    f.write(f"**CWE:** {vuln.cwe}\n")
                f.write(f"\n**描述:**\n{vuln.description}\n\n")
                f.write(f"**攻击向量:** {vuln.attack_vector}\n")
                f.write(f"**影响范围:** {vuln.impact}\n")
                if vuln.code_snippet:
                    f.write(f"\n**代码片段:**\n```python\n{vuln.code_snippet}\n```\n")
                if vuln.remediation:
                    f.write(f"\n**整改建议:**\n{vuln.remediation}\n")

    def load_result(self, task_id: str) -> Optional[AuditResult]:
        """加载审计结果"""
        task_dir = os.path.join(self.base_dir, task_id)
        result_path = os.path.join(task_dir, "result.json")

        if not os.path.exists(result_path):
            return None

        with open(result_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        vulnerabilities = []
        for vuln_data in data.get("vulnerabilities", []):
            vulnerabilities.append(VulnerabilityRecord(
                vulnerability_id=vuln_data["vulnerability_id"],
                type=vuln_data["type"],
                cwe=vuln_data.get("cwe", ""),
                severity=VulnerabilitySeverity(vuln_data.get("severity", "medium")),
                status=VulnerabilityStatus(vuln_data.get("status", "detected")),
                file_path=vuln_data["file_path"],
                line=vuln_data.get("line", 0),
                column=vuln_data.get("column", 0),
                code_snippet=vuln_data.get("code_snippet", ""),
                description=vuln_data.get("description", ""),
                attack_vector=vuln_data.get("attack_vector", ""),
                impact=vuln_data.get("impact", ""),
                exploit_script=vuln_data.get("exploit_script", ""),
                waf_rules=vuln_data.get("waf_rules", []),
                remediation=vuln_data.get("remediation", ""),
                confidence=vuln_data.get("confidence", 0.0)
            ))

        thoughts = []
        for thought_data in data.get("audit_thoughts", []):
            thoughts.append(AuditThought(
                step_number=thought_data["step_number"],
                title=thought_data["title"],
                description=thought_data.get("description", ""),
                code_context=thought_data.get("code_context", ""),
                analysis=thought_data.get("analysis", ""),
                findings=thought_data.get("findings", [])
            ))

        return AuditResult(
            task_id=data["task_id"],
            project_id=data.get("project_id", ""),
            project_name=data.get("project_name", ""),
            source_path=data.get("source_path", ""),
            status=data.get("status", "completed"),
            platform=data.get("platform", "web"),
            vulnerabilities=vulnerabilities,
            audit_thoughts=thoughts,
            execution_time=data.get("execution_time", 0.0)
        )

    def list_results(self) -> List[str]:
        """获取所有任务ID列表"""
        if not os.path.exists(self.base_dir):
            return []
        
        return [name for name in os.listdir(self.base_dir) 
                if os.path.isdir(os.path.join(self.base_dir, name))]

    def delete_result(self, task_id: str) -> bool:
        """删除审计结果"""
        task_dir = os.path.join(self.base_dir, task_id)
        
        if os.path.exists(task_dir):
            shutil.rmtree(task_dir)
            logger.info(f"Deleted audit result: {task_id}")
            return True
        
        return False

    def get_result_summary(self, task_id: str) -> Optional[Dict[str, Any]]:
        """获取审计结果摘要"""
        result = self.load_result(task_id)
        if result:
            return result.get_summary()
        return None