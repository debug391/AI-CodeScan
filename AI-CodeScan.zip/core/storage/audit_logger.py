import os
import logging
from datetime import datetime
from typing import List, Dict, Any

from .models import AuditThought


logger = logging.getLogger("AuditLogger")


class AuditLogger:
    """审计日志记录器 - 记录审计思路和分析过程"""

    def __init__(self, task_id: str, log_dir: str = "data/audit_results"):
        self.task_id = task_id
        self.log_dir = os.path.join(log_dir, task_id)
        self.thoughts: List[AuditThought] = []
        self.step_counter = 0
        
        os.makedirs(self.log_dir, exist_ok=True)

    def add_thought(self, title: str, description: str = "", code_context: str = "", 
                   analysis: str = "", findings: List[str] = None) -> None:
        """添加审计思路"""
        self.step_counter += 1
        
        thought = AuditThought(
            step_number=self.step_counter,
            title=title,
            description=description,
            code_context=code_context,
            analysis=analysis,
            findings=findings or []
        )
        
        self.thoughts.append(thought)
        
        logger.info(f"[AuditStep {self.step_counter}] {title}")
        
        self._write_thought(thought)

    def _write_thought(self, thought: AuditThought) -> None:
        """将单条思路写入文件"""
        thoughts_path = os.path.join(self.log_dir, "audit_thoughts.md")
        
        with open(thoughts_path, 'a', encoding='utf-8') as f:
            f.write(f"\n---\n\n")
            f.write(f"## 步骤 {thought.step_number}: {thought.title}\n\n")
            if thought.description:
                f.write(f"{thought.description}\n\n")
            if thought.code_context:
                f.write(f"### 代码上下文\n\n```python\n{thought.code_context}\n```\n\n")
            if thought.analysis:
                f.write(f"### 分析\n\n{thought.analysis}\n\n")
            if thought.findings:
                f.write(f"### 发现\n\n")
                for finding in thought.findings:
                    f.write(f"- {finding}\n")
            f.write(f"\n*时间戳: {thought.timestamp.isoformat()}*\n")

    def log_recon_start(self, source_path: str) -> None:
        """记录侦察阶段开始"""
        self.add_thought(
            title="开始项目侦察",
            description=f"开始对项目进行侦察分析，源码路径: {source_path}",
            analysis="侦察阶段目标：\n1. 探索项目结构\n2. 识别技术栈\n3. 定位攻击面\n4. 标记高风险文件"
        )

    def log_recon_completed(self, files: List[str], risk_files: List[str], framework_info: Dict[str, Any]) -> None:
        """记录侦察阶段完成"""
        findings = [
            f"发现 {len(files)} 个文件",
            f"识别出 {len(risk_files)} 个高风险文件",
            f"框架类型: {framework_info.get('name', 'Unknown')}",
            f"编程语言: {framework_info.get('language', 'Unknown')}"
        ]
        
        self.add_thought(
            title="项目侦察完成",
            description=f"侦察阶段已完成，识别了项目结构和技术栈",
            analysis=f"高风险文件列表:\n{chr(10).join([f'- {f}' for f in risk_files])}",
            findings=findings
        )

    def log_analysis_start(self, files: List[str]) -> None:
        """记录分析阶段开始"""
        self.add_thought(
            title="开始代码分析",
            description=f"开始分析 {len(files)} 个高风险文件",
            analysis="分析阶段目标：\n1. 静态规则扫描\n2. AI深度分析\n3. 漏洞模式识别\n4. 风险评估"
        )

    def log_vulnerability_found(self, vuln_type: str, file_path: str, line: int, description: str) -> None:
        """记录发现漏洞"""
        self.add_thought(
            title=f"发现漏洞: {vuln_type}",
            description=f"在 {file_path}:{line} 发现 {vuln_type} 漏洞",
            analysis=description,
            findings=[
                f"漏洞类型: {vuln_type}",
                f"位置: {file_path}:{line}",
                f"描述: {description}"
            ]
        )

    def log_analysis_completed(self, vulnerability_count: int) -> None:
        """记录分析阶段完成"""
        self.add_thought(
            title="代码分析完成",
            description=f"分析阶段已完成，共发现 {vulnerability_count} 个漏洞",
            analysis=f"接下来将进行漏洞验证和利用脚本生成"
        )

    def log_verification_start(self) -> None:
        """记录验证阶段开始"""
        self.add_thought(
            title="开始漏洞验证",
            description="开始对发现的漏洞进行验证",
            analysis="验证阶段目标：\n1. 生成POC脚本\n2. 在隔离环境中验证\n3. 收集证据\n4. 排除误报"
        )

    def log_vulnerability_verified(self, vuln_id: str, verified: bool, evidence: str = "") -> None:
        """记录漏洞验证结果"""
        status = "已确认" if verified else "疑似误报"
        self.add_thought(
            title=f"漏洞验证: {vuln_id} - {status}",
            description=f"漏洞 {vuln_id} 验证{status}",
            analysis=evidence[:500] if evidence else ""
        )

    def log_verification_completed(self, verified_count: int, false_positive_count: int) -> None:
        """记录验证阶段完成"""
        findings = [
            f"已验证漏洞: {verified_count}",
            f"误报数量: {false_positive_count}"
        ]
        
        self.add_thought(
            title="漏洞验证完成",
            description=f"验证阶段已完成",
            findings=findings
        )

    def log_report_generation(self, report_path: str) -> None:
        """记录报告生成"""
        self.add_thought(
            title="生成审计报告",
            description=f"审计报告已生成: {report_path}",
            analysis="报告包含：\n1. 漏洞统计摘要\n2. 漏洞详情列表\n3. 利用脚本\n4. WAF规则\n5. 整改建议"
        )

    def get_thoughts(self) -> List[AuditThought]:
        """获取所有审计思路"""
        return self.thoughts

    def save_thoughts(self) -> None:
        """保存所有思路到文件"""
        thoughts_path = os.path.join(self.log_dir, "audit_thoughts.json")
        
        with open(thoughts_path, 'w', encoding='utf-8') as f:
            import json
            json.dump([t.to_dict() for t in self.thoughts], f, indent=2, ensure_ascii=False)
        
        logger.info(f"Audit thoughts saved to: {thoughts_path}")