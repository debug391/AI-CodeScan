import asyncio
import os
import tempfile
import shutil
import uuid
import logging

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s"
)

from core.skills.manager import SkillManager
from core.ai.analyzer import AIAnalyzer
from core.storage.result_store import ResultStore
from core.storage.audit_logger import AuditLogger
from core.storage.models import AuditResult, VulnerabilityRecord, VulnerabilitySeverity, VulnerabilityStatus
from core.exploit.generator import ExploitGenerator
from core.exploit.waf_rule_generator import WAFRuleGenerator
from core.exploit.models import ExploitConfig, ExploitType


class MockWebProjectGenerator:
    """模拟Web项目生成器"""
    
    @staticmethod
    def generate(project_path: str):
        """生成模拟的Web项目"""
        os.makedirs(project_path, exist_ok=True)
        
        with open(os.path.join(project_path, "app.py"), 'w') as f:
            f.write('''from flask import Flask, request, jsonify
import pymysql
import subprocess

app = Flask(__name__)

SECRET_KEY = "supersecretkey123"
DB_PASSWORD = "password123"

@app.route('/login', methods=['POST'])
def login():
    username = request.form.get('username')
    password = request.form.get('password')
    query = f"SELECT * FROM users WHERE username='{username}' AND password='{password}'"
    db = pymysql.connect(host='localhost', user='root', password=DB_PASSWORD)
    cursor = db.cursor()
    cursor.execute(query)
    result = cursor.fetchone()
    if result:
        return jsonify({"success": True})
    return jsonify({"success": False})

@app.route('/search', methods=['GET'])
def search():
    keyword = request.args.get('q')
    query = f"SELECT * FROM products WHERE name LIKE '%{keyword}%'"
    return jsonify({"query": query})

@app.route('/execute', methods=['POST'])
def execute():
    cmd = request.json.get('command')
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return jsonify({"output": result.stdout})

@app.route('/upload', methods=['POST'])
def upload():
    file = request.files['file']
    filename = request.form.get('filename', file.filename)
    file.save(f'/uploads/{filename}')
    return jsonify({"status": "success"})

if __name__ == '__main__':
    app.run(debug=True)
''')
        
        with open(os.path.join(project_path, "config.py"), 'w') as f:
            f.write('''DEBUG = True
DATABASE_URL = "mysql://root:password@localhost/db"
ALLOWED_HOSTS = ["*"]
API_KEY = "test-api-key-123"
''')
        
        with open(os.path.join(project_path, "utils.py"), 'w') as f:
            f.write('''import hashlib

def hash_password(password):
    return hashlib.md5(password.encode()).hexdigest()

def load_config():
    return {
        "secret": "hardcoded-secret",
        "api_key": "test-key"
    }
''')
        
        print(f"[*] 模拟Web项目生成完成: {project_path}")


class AuditWorkflow:
    """完整审计工作流"""
    
    def __init__(self):
        self.task_id = f"audit-{uuid.uuid4().hex[:8]}"
        self.project_id = f"proj-{uuid.uuid4().hex[:8]}"
        self.project_name = "Demo Web Application"
        
        self.skill_manager = SkillManager()
        self.ai_analyzer = AIAnalyzer()
        self.result_store = ResultStore()
        self.audit_logger = AuditLogger(self.task_id)
        self.exploit_generator = ExploitGenerator()
        self.waf_generator = WAFRuleGenerator()
        
        self.audit_result = AuditResult(
            task_id=self.task_id,
            project_id=self.project_id,
            project_name=self.project_name,
            source_path=""
        )
    
    async def run(self, source_path: str):
        """运行完整审计流程"""
        print("\n" + "="*70)
        print(f"开始完整审计流程 - 任务ID: {self.task_id}")
        print("="*70)
        
        self.audit_result.source_path = source_path
        
        # 阶段1: 侦察
        print("\n[阶段1] 项目侦察")
        self.audit_logger.log_recon_start(source_path)
        await self._recon_phase(source_path)
        
        # 阶段2: 静态分析
        print("\n[阶段2] 静态代码分析")
        self.audit_logger.log_analysis_start(self.risk_files)
        await self._analysis_phase(source_path)
        
        # 阶段3: AI深度分析
        print("\n[阶段3] AI智能分析")
        await self._ai_analysis_phase(source_path)
        
        # 阶段4: 漏洞验证和利用生成
        print("\n[阶段4] 漏洞验证与利用生成")
        self.audit_logger.log_verification_start()
        await self._verification_phase()
        
        # 阶段5: 结果存储
        print("\n[阶段5] 保存审计结果")
        await self._save_results()
        
        print("\n" + "="*70)
        print("审计流程完成")
        print("="*70)
        
        return self.audit_result
    
    async def _recon_phase(self, source_path: str):
        """侦察阶段"""
        files = []
        risk_files = []
        
        for root, dirs, filenames in os.walk(source_path):
            for filename in filenames:
                file_path = os.path.join(root, filename)
                files.append(file_path)
                
                if filename in ["app.py", "config.py"]:
                    risk_files.append(file_path)
        
        framework_info = {
            "name": "Flask",
            "language": "Python",
            "database": "MySQL"
        }
        
        self.files = files
        self.risk_files = risk_files
        self.framework_info = framework_info
        
        self.audit_logger.log_recon_completed(files, risk_files, framework_info)
        
        print(f"  发现文件: {len(files)} 个")
        print(f"  高风险文件: {len(risk_files)} 个")
        print(f"  技术栈: {framework_info['name']} + {framework_info['language']}")
    
    async def _analysis_phase(self, source_path: str):
        """静态分析阶段"""
        vulnerabilities = []
        vuln_id = 1
        
        for file_path in self.risk_files:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            if "f\"SELECT" in content or "f'SELECT" in content:
                vulnerabilities.append({
                    "type": "SQL注入",
                    "cwe": "CWE-89",
                    "severity": "critical",
                    "file_path": file_path,
                    "line": content.count('\n', 0, content.find("f\"SELECT")) + 1,
                    "description": "SQL查询直接拼接用户输入",
                    "code_snippet": "query = f\"SELECT * FROM users WHERE username='{username}'\"",
                    "attack_vector": "HTTP请求参数",
                    "impact": "数据库信息泄露、认证绕过"
                })
                self.audit_logger.log_vulnerability_found("SQL注入", file_path, vuln_id, "SQL查询直接拼接用户输入")
                vuln_id += 1
            
            if "subprocess.run(" in content and "shell=True" in content:
                vulnerabilities.append({
                    "type": "命令注入",
                    "cwe": "CWE-78",
                    "severity": "critical",
                    "file_path": file_path,
                    "line": content.count('\n', 0, content.find("subprocess.run")) + 1,
                    "description": "用户输入直接传递给shell命令",
                    "code_snippet": "subprocess.run(cmd, shell=True)",
                    "attack_vector": "HTTP请求参数",
                    "impact": "远程命令执行"
                })
                self.audit_logger.log_vulnerability_found("命令注入", file_path, vuln_id, "用户输入直接传递给shell命令")
                vuln_id += 1
            
            if "DEBUG = True" in content:
                vulnerabilities.append({
                    "type": "调试模式启用",
                    "cwe": "CWE-200",
                    "severity": "medium",
                    "file_path": file_path,
                    "line": content.count('\n', 0, content.find("DEBUG = True")) + 1,
                    "description": "生产环境启用了调试模式",
                    "code_snippet": "DEBUG = True",
                    "attack_vector": "直接访问",
                    "impact": "敏感信息泄露"
                })
                self.audit_logger.log_vulnerability_found("调试模式", file_path, vuln_id, "生产环境启用了调试模式")
                vuln_id += 1
            
            if "password" in content.lower() and ("=" in content or ":" in content):
                vulnerabilities.append({
                    "type": "硬编码凭证",
                    "cwe": "CWE-798",
                    "severity": "critical",
                    "file_path": file_path,
                    "line": content.count('\n', 0, content.lower().find("password")) + 1,
                    "description": "配置文件中存在硬编码密码",
                    "code_snippet": 'DB_PASSWORD = "password123"',
                    "attack_vector": "代码泄露",
                    "impact": "凭证泄露"
                })
                self.audit_logger.log_vulnerability_found("硬编码凭证", file_path, vuln_id, "配置文件中存在硬编码密码")
                vuln_id += 1
        
        self.static_vulnerabilities = vulnerabilities
        self.audit_logger.log_analysis_completed(len(vulnerabilities))
        
        print(f"  静态分析发现漏洞: {len(vulnerabilities)} 个")
    
    async def _ai_analysis_phase(self, source_path: str):
        """AI分析阶段"""
        ai_results = self.ai_analyzer.analyze_project(source_path)
        
        ai_vulnerabilities = []
        for result in ai_results:
            ai_vulnerabilities.extend(result.vulnerabilities)
        
        self.ai_vulnerabilities = ai_vulnerabilities
        
        print(f"  AI分析发现漏洞: {len(ai_vulnerabilities)} 个")
    
    async def _verification_phase(self):
        """漏洞验证阶段"""
        all_vulnerabilities = self.static_vulnerabilities
        
        verified_count = 0
        false_positive_count = 0
        
        for vuln in all_vulnerabilities:
            vuln_record = VulnerabilityRecord(
                vulnerability_id=f"VULN-{str(uuid.uuid4())[:6]}",
                type=vuln["type"],
                cwe=vuln.get("cwe", ""),
                severity=VulnerabilitySeverity(vuln["severity"]),
                status=VulnerabilityStatus.VERIFIED,
                file_path=vuln["file_path"],
                line=vuln["line"],
                code_snippet=vuln.get("code_snippet", ""),
                description=vuln.get("description", ""),
                attack_vector=vuln.get("attack_vector", ""),
                impact=vuln.get("impact", ""),
                confidence=0.85
            )
            
            type_mapping = {
                "SQL注入": "sql_injection",
                "命令注入": "command_injection",
                "调试模式": "other",
                "硬编码凭证": "hardcoded_credentials"
            }
            vuln_type_str = type_mapping.get(vuln["type"], "other")
            exploit_config = ExploitConfig(
                target_url="http://example.com",
                vulnerability_type=ExploitType(vuln_type_str),
                parameters={}
            )
            exploit_result = self.exploit_generator.generate_exploit_script(exploit_config)
            vuln_record.exploit_script = exploit_result
            
            waf_rules = self.waf_generator.generate_rules_for_payload(vuln.get("code_snippet", ""))
            vuln_record.waf_rules = [rule.to_modsecurity() for rule in waf_rules]
            
            remediation = self.waf_generator.generate_remediation_advice(vuln.get("type", ""))
            vuln_record.remediation = remediation.description
            
            self.audit_result.add_vulnerability(vuln_record)
            self.audit_logger.log_vulnerability_verified(vuln_record.vulnerability_id, True)
            
            verified_count += 1
        
        self.audit_logger.log_verification_completed(verified_count, false_positive_count)
        
        print(f"  已验证漏洞: {verified_count} 个")
        print(f"  误报: {false_positive_count} 个")
    
    async def _save_results(self):
        """保存审计结果"""
        self.audit_result.audit_thoughts = self.audit_logger.get_thoughts()
        self.audit_result.status = "completed"
        
        save_path = self.result_store.save_result(self.audit_result)
        self.audit_logger.log_report_generation(save_path)
        self.audit_logger.save_thoughts()
        
        print(f"  审计报告已保存到: {save_path}")
        
        self._print_summary()
    
    def _print_summary(self):
        """打印审计摘要"""
        summary = self.audit_result.get_summary()
        
        print("\n" + "="*70)
        print("审计报告摘要")
        print("="*70)
        print(f"项目名称: {self.project_name}")
        print(f"任务ID: {self.task_id}")
        print(f"总漏洞数: {summary['total_vulnerabilities']}")
        print(f"Critical: {summary['severity_counts']['critical']}")
        print(f"High: {summary['severity_counts']['high']}")
        print(f"Medium: {summary['severity_counts']['medium']}")
        print(f"Low: {summary['severity_counts']['low']}")
        print("="*70)
        
        print("\n漏洞详情:")
        for vuln in self.audit_result.vulnerabilities:
            print(f"\n  [{vuln.vulnerability_id}] {vuln.type}")
            print(f"    严重程度: {vuln.severity.value.upper()}")
            print(f"    位置: {vuln.file_path}:{vuln.line}")
            print(f"    描述: {vuln.description}")


async def main():
    """主函数"""
    print("\n" + "="*70)
    print("代码审计平台 - 完整流程演示")
    print("="*70)
    
    with tempfile.TemporaryDirectory() as temp_dir:
        # 生成模拟项目
        project_path = os.path.join(temp_dir, "demo_project")
        MockWebProjectGenerator.generate(project_path)
        
        # 显示项目结构
        print("\n[项目结构]")
        for root, dirs, files in os.walk(project_path):
            level = root.replace(project_path, '').count(os.sep)
            indent = ' ' * 2 * level
            print(f"{indent}{os.path.basename(root)}/")
            subindent = ' ' * 2 * (level + 1)
            for file in files:
                print(f"{subindent}{file}")
        
        # 运行审计流程
        workflow = AuditWorkflow()
        result = await workflow.run(project_path)
        
        # 显示保存的文件
        print("\n[保存的审计结果文件]")
        result_dir = os.path.join("data/audit_results", workflow.task_id)
        if os.path.exists(result_dir):
            for root, dirs, files in os.walk(result_dir):
                level = root.replace(result_dir, '').count(os.sep)
                indent = ' ' * 2 * level
                print(f"{indent}{os.path.basename(root)}/")
                subindent = ' ' * 2 * (level + 1)
                for file in files:
                    file_path = os.path.join(root, file)
                    size = os.path.getsize(file_path)
                    print(f"{subindent}{file} ({size} bytes)")


if __name__ == "__main__":
    asyncio.run(main())
