# 代码安全审计报告

## 项目信息

- 项目名称: Demo Web Application
- 项目ID: proj-5f9a3fb5
- 任务ID: audit-409c4b8f
- 源码路径: C:\Users\ADMINI~1\AppData\Local\Temp\tmpuibzxzvb\demo_project
- 平台类型: web
- 审计状态: completed
- 执行时间: 0.00 秒
- 生成时间: 2026-06-05T06:36:25.015844

## 漏洞统计

- 总漏洞数: 5
- Critical: 4
- High: 0
- Medium: 1
- Low: 0

## 漏洞详情

---

### [VULN-473d9e] SQL注入

**严重程度:** CRITICAL
**状态:** verified
**位置:** C:\Users\ADMINI~1\AppData\Local\Temp\tmpuibzxzvb\demo_project\app.py:14
**CWE:** CWE-89

**描述:**
SQL查询直接拼接用户输入

**攻击向量:** HTTP请求参数
**影响范围:** 数据库信息泄露、认证绕过

**代码片段:**
```python
query = f"SELECT * FROM users WHERE username='{username}'"
```
---

### [VULN-f14729] 命令注入

**严重程度:** CRITICAL
**状态:** verified
**位置:** C:\Users\ADMINI~1\AppData\Local\Temp\tmpuibzxzvb\demo_project\app.py:32
**CWE:** CWE-78

**描述:**
用户输入直接传递给shell命令

**攻击向量:** HTTP请求参数
**影响范围:** 远程命令执行

**代码片段:**
```python
subprocess.run(cmd, shell=True)
```
---

### [VULN-d3827b] 硬编码凭证

**严重程度:** CRITICAL
**状态:** verified
**位置:** C:\Users\ADMINI~1\AppData\Local\Temp\tmpuibzxzvb\demo_project\app.py:8
**CWE:** CWE-798

**描述:**
配置文件中存在硬编码密码

**攻击向量:** 代码泄露
**影响范围:** 凭证泄露

**代码片段:**
```python
DB_PASSWORD = "password123"
```
---

### [VULN-c931f2] 调试模式启用

**严重程度:** MEDIUM
**状态:** verified
**位置:** C:\Users\ADMINI~1\AppData\Local\Temp\tmpuibzxzvb\demo_project\config.py:1
**CWE:** CWE-200

**描述:**
生产环境启用了调试模式

**攻击向量:** 直接访问
**影响范围:** 敏感信息泄露

**代码片段:**
```python
DEBUG = True
```
---

### [VULN-5a491b] 硬编码凭证

**严重程度:** CRITICAL
**状态:** verified
**位置:** C:\Users\ADMINI~1\AppData\Local\Temp\tmpuibzxzvb\demo_project\config.py:2
**CWE:** CWE-798

**描述:**
配置文件中存在硬编码密码

**攻击向量:** 代码泄露
**影响范围:** 凭证泄露

**代码片段:**
```python
DB_PASSWORD = "password123"
```
