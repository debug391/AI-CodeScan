# 代码安全审计报告

## 项目信息

- 项目名称: php代码审计测试
- 项目ID: proj-62fccba4
- 任务ID: audit-4e688ddf
- 源码路径: C:\Users\ADMINI~1\AppData\Local\Temp\tmpa0jgm9b8
- 平台类型: web
- 审计状态: completed
- 执行时间: 0.00 秒
- 生成时间: 2026-06-05T06:51:25.319730

## 漏洞统计

- 总漏洞数: 0
- Critical: 0
- High: 0
- Medium: 0
- Low: 0

## 漏洞详情

