# 代码安全审计报告

## 项目信息

- 项目名称: java审计测试
- 项目ID: proj-e3e6d0c9
- 任务ID: audit-0a0b8950
- 源码路径: C:\Users\ADMINI~1\AppData\Local\Temp\tmpalhxq6vi
- 平台类型: web
- 审计状态: completed
- 执行时间: 0.00 秒
- 生成时间: 2026-06-05T06:59:11.654592

## 漏洞统计

- 总漏洞数: 0
- Critical: 0
- High: 0
- Medium: 0
- Low: 0

## 漏洞详情

