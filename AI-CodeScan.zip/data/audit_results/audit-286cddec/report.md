# 代码安全审计报告

## 项目信息

- 项目名称: php审计测试
- 项目ID: proj-18ca5b2c
- 任务ID: audit-286cddec
- 源码路径: C:\Users\ADMINI~1\AppData\Local\Temp\tmpkocg2bm4
- 平台类型: web
- 审计状态: completed
- 执行时间: 0.00 秒
- 生成时间: 2026-06-05T06:54:27.165449

## 漏洞统计

- 总漏洞数: 0
- Critical: 0
- High: 0
- Medium: 0
- Low: 0

## 漏洞详情

